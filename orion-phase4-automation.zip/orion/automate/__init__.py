
"""Automation package for Orion Content Management System."""

__version__ = "1.0.0"
