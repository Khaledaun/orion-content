
# Phase 8 Production Runbooks

## Emergency Procedures

### 🚨 Emergency Disable Quality Enforcement

**When to Use**: Critical content needs to be published immediately, bypassing quality checks.

**Steps**:
```bash
# 1. Disable enforcement for 30 minutes
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     https://app.example.com/api/ops/controls \
     --data '{
       "action": "disable_enforcement",
       "duration": 30,
       "reason": "Emergency content deployment - ticket #ABC123"
     }'

# 2. Verify status
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     https://app.example.com/api/ops/controls

# 3. Process urgent content
# (Content will bypass quality checks but still be logged)

# 4. Re-enable enforcement (automatic after 30 min, or manual)
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     https://app.example.com/api/ops/controls \
     --data '{"action": "enable_enforcement"}'
```

**Post-Action**:
- [ ] Review content quality after emergency
- [ ] Document incident in ops log
- [ ] Update procedures if needed

### 🧪 Enable Dry-Run Mode

**When to Use**: Testing pipeline changes without affecting WordPress.

**Steps**:
```bash
# 1. Enable dry-run for 1 hour
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     https://app.example.com/api/ops/controls \
     --data '{
       "action": "set_dry_run",
       "duration": 60,
       "reason": "Testing pipeline changes - deployment v2.1"
     }'

# 2. Run test content
# (Pipeline will execute fully but won't push to WordPress)

# 3. Review observability logs
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     "https://app.example.com/api/ops/metrics?days=1" | jq '.timeSeries'

# 4. Disable dry-run when ready
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     https://app.example.com/api/ops/controls \
     --data '{"action": "enable_enforcement"}'
```

### ⏪ Emergency Rollback

**When to Use**: Current rulebook version is causing issues, need to revert to previous version.

**Steps**:
```bash
# 1. Check current rulebook version
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     https://app.example.com/api/ops/status | jq '.rulebook'

# 2. List available versions
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     https://app.example.com/api/rulebook/versions

# 3. Emergency rollback to previous version (e.g., v3)
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     https://app.example.com/api/ops/controls \
     --data '{
       "action": "emergency_rollback",
       "targetVersion": 3,
       "reason": "Critical quality issues with v4 - incident #DEF456"
     }'

# 4. Verify rollback
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     https://app.example.com/api/ops/status | jq '.rulebook.activeVersion'

# 5. Test content processing
# (Process sample content to ensure rollback successful)
```

**Post-Rollback**:
- [ ] Notify development team
- [ ] Investigate root cause of v4 issues
- [ ] Plan fix and re-deployment
- [ ] Update incident documentation

## Rate Limit Exhaustion Handling

### 📊 Monitoring Rate Limits

**Check Current Status**:
```bash
# Check rate limit hits in last 24 hours
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     https://app.example.com/api/ops/status | jq '.audits.rateLimitHits24Hours'

# Get detailed metrics
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     "https://app.example.com/api/ops/metrics?days=1&groupBy=hour" | \
     jq '.timeSeries[] | select(.errors > 0)'
```

### 🔧 Handling Rate Limit Exhaustion

**Scenario**: API rate limits are being hit frequently, blocking content processing.

**Immediate Actions**:
```bash
# 1. Check which endpoints are hitting limits
grep "rate_limit_exceeded" /var/log/app/audit.log | tail -20

# 2. Temporarily increase limits (if Redis-based)
# Connect to Redis and check current windows
redis-cli -u $REDIS_URL
> KEYS rate_limit:*
> TTL rate_limit:api_rulebook:192.168.1.100

# 3. If critically needed, temporarily disable rate limiting
# (USE WITH EXTREME CAUTION)
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     https://app.example.com/api/ops/controls \
     --data '{
       "action": "disable_rate_limiting",
       "duration": 15,
       "reason": "Critical backlog processing - incident #GHI789"
     }'
```

**Medium-term Solutions**:
1. **Scale horizontally**: Deploy multiple instances behind load balancer
2. **Optimize request patterns**: Batch processing, intelligent queueing
3. **Adjust rate limits**: Review and increase limits based on capacity

**Configuration Updates**:
```typescript
// lib/rate-limit-prod.ts - Adjust limits
export const RATE_LIMITS = {
  api: {
    rulebook: {
      get: { windowMs: 60000, limit: 50 },  // Increased from 30
      post: { windowMs: 300000, limit: 10 } // Increased from 5
    }
  }
}
```

## Cost Management

### 💰 Daily Cost Monitoring

**Daily Cost Check**:
```bash
# Get today's costs
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     "https://app.example.com/api/ops/metrics?days=1" | \
     jq '{
       totalCost: .summary.totalCost,
       openaiCost: .costByProvider.openai,
       perplexityCost: .costByProvider.perplexity,
       totalRequests: .summary.totalReports
     }'

# Weekly trend
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     "https://app.example.com/api/ops/metrics?days=7&groupBy=day" | \
     jq '.timeSeries[] | {date: .timestamp, cost: .cost}'
```

**Cost Alert Thresholds**:
- **Daily**: >$100 (alert)
- **Weekly**: >$500 (review)
- **Monthly**: >$2000 (escalate)

### 🔍 Cost Investigation

**High Cost Day Investigation**:
```bash
# 1. Check model usage distribution
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     "https://app.example.com/api/ops/metrics?days=1" | \
     jq '.topModels | sort_by(.cost) | reverse'

# 2. Check for cost anomalies
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     "https://app.example.com/api/ops/metrics?days=1&groupBy=hour" | \
     jq '.timeSeries[] | select(.cost > 10)'

# 3. Review recent pipeline executions
grep "pipeline_completed" /var/log/app/audit.log | \
     tail -50 | jq -r '.metadata.totalCost' | \
     awk '{sum+=$1; count++} END {print "Avg cost per pipeline:", sum/count}'
```

**Cost Optimization Actions**:
```bash
# Switch to more cost-effective models temporarily
export OPENAI_MODEL=gpt-3.5-turbo  # Instead of gpt-4
export PERPLEXITY_MODEL=pplx-7b-online  # Instead of pplx-70b-online

# Enable research result caching
export CACHE_RESEARCH_RESULTS=true
export CACHE_TTL_SECONDS=7200  # 2 hours

# Reduce content length for lower-priority sites
export DEFAULT_MAX_WORDS=800  # Instead of 1200
```

## System Health Monitoring

### 🏥 Health Check Procedures

**Comprehensive Health Check**:
```bash
#!/bin/bash
# health-check.sh

echo "=== System Health Check ==="
echo "Timestamp: $(date)"

# 1. API Health
echo "1. API Health:"
curl -f http://localhost:3000/api/health || echo "FAILED"

# 2. Database connectivity
echo "2. Database:"
npx prisma db pull --preview-feature > /dev/null && echo "OK" || echo "FAILED"

# 3. Redis connectivity
echo "3. Redis:"
redis-cli -u $REDIS_URL ping || echo "FAILED"

# 4. External APIs
echo "4. OpenAI API:"
curl -s -H "Authorization: Bearer $OPENAI_API_KEY" \
     https://api.openai.com/v1/models > /dev/null && echo "OK" || echo "FAILED"

echo "5. Perplexity API:"
# Test with simple request
timeout 10s curl -s -H "Authorization: Bearer $PERPLEXITY_API_KEY" \
     https://api.perplexity.ai/chat/completions \
     -d '{"model":"pplx-7b-online","messages":[{"role":"user","content":"test"}]}' > /dev/null && echo "OK" || echo "TIMEOUT/FAILED"

# 6. Recent error rate
echo "6. Error rate (last hour):"
error_count=$(grep "$(date '+%Y-%m-%d %H')" /var/log/app/audit.log | grep -c '"success":false')
total_count=$(grep "$(date '+%Y-%m-%d %H')" /var/log/app/audit.log | grep -c 'pipeline_completed\|pipeline_failed')
if [ $total_count -gt 0 ]; then
    error_rate=$(echo "scale=2; $error_count * 100 / $total_count" | bc)
    echo "${error_rate}% error rate ($error_count/$total_count)"
else
    echo "No recent activity"
fi

echo "=== Health Check Complete ==="
```

**Automated Health Monitoring**:
```bash
# Add to cron for regular checks
# */15 * * * * /path/to/health-check.sh >> /var/log/health-check.log 2>&1
```

### 🔧 Service Recovery Procedures

**Database Connection Lost**:
```bash
# 1. Check database status
pg_isready -h your-db-host -p 5432

# 2. Check connection pool
ps aux | grep prisma

# 3. Restart application
systemctl restart your-app
# OR
pm2 restart your-app

# 4. Verify recovery
curl -f http://localhost:3000/api/health
```

**Redis Connection Lost**:
```bash
# 1. Check Redis status
redis-cli -u $REDIS_URL ping

# 2. If Redis is down, app should fall back to memory
# Check logs for fallback messages
grep "Redis connection error, falling back to memory" /var/log/app/*.log

# 3. If critical, restart Redis service or switch Redis instance

# 4. Verify rate limiting still works (may be memory-based)
```

**OpenAI/Perplexity API Issues**:
```bash
# 1. Check API status
curl -s https://status.openai.com/api/v2/status.json
curl -s https://status.perplexity.ai/api/v2/status.json

# 2. Enable content generation fallback mode
export CONTENT_GENERATION_FALLBACK=true

# 3. Monitor error rates
grep "api_request_failed" /var/log/app/audit.log | tail -10

# 4. If critical, enable dry-run mode until APIs recover
```

## Capacity Planning

### 📈 Traffic Growth Planning

**Current Capacity Baseline**:
- **10 concurrent sites**: 95%+ success rate
- **20 concurrent sites**: 90%+ success rate  
- **Average cost per pipeline**: $0.07
- **Average latency**: 5-6 seconds

**Scaling Thresholds**:
- **>25 concurrent sites**: Consider horizontal scaling
- **>$200/day costs**: Review efficiency and pricing tiers
- **>10% error rate**: Immediate investigation required

**Horizontal Scaling Setup**:
```bash
# Load balancer configuration (nginx example)
upstream orion_backend {
    server app1.internal:3000 max_fails=3 fail_timeout=30s;
    server app2.internal:3000 max_fails=3 fail_timeout=30s;
    server app3.internal:3000 max_fails=3 fail_timeout=30s;
}

server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://orion_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

**Database Scaling**:
- **Read replicas**: For analytics and reporting queries
- **Connection pooling**: PgBouncer for high-concurrency
- **Partitioning**: Large audit log tables by date

**Redis Scaling**:
- **Clustering**: Redis Cluster for high availability
- **Replication**: Master-slave setup with failover
- **Persistent storage**: RDB + AOF for durability

## Incident Response

### 🚨 Incident Classification

**Severity 1 (Critical)**:
- Complete service outage
- Data loss or corruption
- Security breach
- **Response Time**: 15 minutes
- **Escalation**: Immediate

**Severity 2 (High)**:
- Partial service degradation
- High error rates (>20%)
- API integration failures
- **Response Time**: 1 hour
- **Escalation**: 2 hours if unresolved

**Severity 3 (Medium)**:
- Performance issues
- Non-critical feature failures
- Cost overruns
- **Response Time**: 4 hours
- **Escalation**: Next business day

### 📞 Incident Response Checklist

**Initial Response (First 15 minutes)**:
- [ ] Assess severity and impact
- [ ] Create incident ticket/channel
- [ ] Run health check script
- [ ] Check recent deployments/changes
- [ ] Notify stakeholders if Sev 1/2

**Investigation Phase**:
- [ ] Gather logs and metrics
- [ ] Review recent audit logs
- [ ] Check external service status
- [ ] Identify root cause
- [ ] Document findings

**Resolution Phase**:
- [ ] Implement fix or workaround
- [ ] Test resolution
- [ ] Monitor for stability
- [ ] Update incident documentation
- [ ] Schedule post-mortem if Sev 1/2

**Communication Templates**:

```
Subject: [SEV 1] Orion Content Service Outage

INCIDENT: Complete service outage
IMPACT: All content processing stopped
START TIME: 2025-08-29 14:30 UTC
STATUS: Investigating
NEXT UPDATE: 15 minutes

Initial investigation shows database connection issues.
Working on immediate restoration.

- Incident Commander: [Name]
- Next update in 15 minutes
```

### 📊 Post-Incident Review

**Post-Mortem Template**:
1. **Incident Summary**
   - Duration, impact, severity
   - Root cause summary

2. **Timeline**
   - Key events with timestamps
   - Response actions taken

3. **Root Cause Analysis**  
   - Technical root cause
   - Contributing factors
   - Why detection took X minutes

4. **Action Items**
   - Prevention measures
   - Detection improvements
   - Process improvements
   - Owners and due dates

5. **Lessons Learned**
   - What went well
   - What could be improved
   - Process changes needed

This completes the comprehensive runbook for Phase 8 production operations.
