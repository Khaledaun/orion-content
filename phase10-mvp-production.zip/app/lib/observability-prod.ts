
import { redactSecrets } from './redact'

export interface CostMetrics {
  totalCost: number;
  tokenUsage: number;
  requestCount: number;
  period: {
    startDate: string;
    endDate: string;
    days: number;
  };
}

export interface ObservabilityReport {
  id: string;
  createdAt: string;
  totalLatencyMs: number;
  stages: Array<{
    name: string;
    success: boolean;
    latencyMs: number;
    error?: string;
  }>;
}

export async function getCostMetrics(days: number = 7): Promise<CostMetrics> {
  const endDate = new Date();
  const startDate = new Date(endDate.getTime() - days * 24 * 60 * 60 * 1000);

  // Mock data - in production this would query actual cost tracking
  const rawMetrics = {
    totalCost: Math.random() * 100,
    tokenUsage: Math.floor(Math.random() * 10000),
    requestCount: Math.floor(Math.random() * 1000),
    period: {
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      days
    }
  };

  // Apply redaction before returning
  return redactSecrets(rawMetrics) as CostMetrics;
}

export async function getObservabilityReports(limit: number = 100): Promise<ObservabilityReport[]> {
  // Mock data - in production this would query actual observability data
  const reports: ObservabilityReport[] = [];
  
  for (let i = 0; i < Math.min(limit, 10); i++) {
    const rawReport = {
      id: `report-${i}`,
      createdAt: new Date(Date.now() - i * 60000).toISOString(),
      totalLatencyMs: Math.random() * 1000,
      stages: [
        {
          name: 'auth',
          success: Math.random() > 0.1,
          latencyMs: Math.random() * 100,
          // Simulate potential sensitive data that needs redaction
          metadata: {
            apiKey: 'sk-test123456789',
            userEmail: 'user@example.com',
            token: 'bearer_token_12345'
          }
        },
        {
          name: 'processing',
          success: Math.random() > 0.05,
          latencyMs: Math.random() * 500,
          error: Math.random() > 0.8 ? 'Database connection failed with password=secret123' : undefined
        }
      ]
    };
    
    // Apply redaction to each report before adding to results
    reports.push(redactSecrets(rawReport) as ObservabilityReport);
  }
  
  return reports;
}

/**
 * Generates a comprehensive observability report with full redaction
 * This is used by the /api/ops/metrics endpoint and observability.json generation
 */
export function generateObservabilityReport(): any {
  const rawReport = {
    timestamp: new Date().toISOString(),
    service: 'orion-content',
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'development',
    metrics: {
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      cpu: process.cpuUsage()
    },
    // Simulate environment data that might contain secrets
    config: {
      databaseUrl: process.env.DATABASE_URL || 'postgresql://user:password@localhost:5432/db',
      redisUrl: process.env.REDIS_URL || 'redis://user:password@localhost:6379',
      openaiKey: process.env.OPENAI_API_KEY || 'sk-test123456789',
      sessionSecret: process.env.SESSION_SECRET || 'super-secret-session-key'
    },
    // Simulate request logs that might contain sensitive data
    recentRequests: [
      {
        method: 'POST',
        url: '/api/auth/login',
        headers: {
          authorization: 'Bearer sk-test123456789',
          cookie: 'session=abc123; token=xyz789'
        },
        body: {
          email: 'user@example.com',
          password: 'user-password-123'
        }
      }
    ]
  };

  // Apply comprehensive redaction before returning
  return redactSecrets(rawReport);
}
