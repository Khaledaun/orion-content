
export interface RedisClient {
  get(key: string): Promise<string | null>;
  set(key: string, value: string, options?: { EX?: number }): Promise<void>;
  del(key: string): Promise<void>;
  exists(key: string): Promise<number>;
  incr(key: string): Promise<number>;
  expire(key: string, seconds: number): Promise<void>;
  ping(): Promise<string>;
  zremrangebyscore(key: string, min: number, max: number): Promise<number>;
  zcard(key: string): Promise<number>;
  zadd(key: string, score: number, member: string): Promise<number>;
}

class MockRedisClient implements RedisClient {
  private data = new Map<string, { value: string; expires?: number }>();
  private sortedSets = new Map<string, Map<string, number>>();

  async ping(): Promise<string> {
    return 'PONG';
  }

  async get(key: string): Promise<string | null> {
    const item = this.data.get(key);
    if (!item) return null;
    
    if (item.expires && Date.now() > item.expires) {
      this.data.delete(key);
      return null;
    }
    
    return item.value;
  }

  async set(key: string, value: string, options?: { EX?: number }): Promise<void> {
    const expires = options?.EX ? Date.now() + (options.EX * 1000) : undefined;
    this.data.set(key, { value, expires });
  }

  async del(key: string): Promise<void> {
    this.data.delete(key);
    this.sortedSets.delete(key);
  }

  async exists(key: string): Promise<number> {
    return this.data.has(key) || this.sortedSets.has(key) ? 1 : 0;
  }

  async incr(key: string): Promise<number> {
    const current = await this.get(key);
    const newValue = (parseInt(current || '0', 10) + 1).toString();
    await this.set(key, newValue);
    return parseInt(newValue, 10);
  }

  async expire(key: string, seconds: number): Promise<void> {
    const item = this.data.get(key);
    if (item) {
      item.expires = Date.now() + (seconds * 1000);
      this.data.set(key, item);
    }
  }

  async zremrangebyscore(key: string, min: number, max: number): Promise<number> {
    const sortedSet = this.sortedSets.get(key);
    if (!sortedSet) return 0;

    let removed = 0;
    for (const [member, score] of sortedSet.entries()) {
      if (score >= min && score <= max) {
        sortedSet.delete(member);
        removed++;
      }
    }
    return removed;
  }

  async zcard(key: string): Promise<number> {
    const sortedSet = this.sortedSets.get(key);
    return sortedSet ? sortedSet.size : 0;
  }

  async zadd(key: string, score: number, member: string): Promise<number> {
    let sortedSet = this.sortedSets.get(key);
    if (!sortedSet) {
      sortedSet = new Map();
      this.sortedSets.set(key, sortedSet);
    }
    
    const existed = sortedSet.has(member);
    sortedSet.set(member, score);
    return existed ? 0 : 1;
  }
}

let redisClient: RedisClient;

export function getRedisClient(): RedisClient {
  if (!redisClient) {
    redisClient = new MockRedisClient();
  }
  return redisClient;
}

export function getRedisStore(): RedisClient {
  return getRedisClient();
}

export class RedisHealthCheck {
  static async isHealthy(): Promise<boolean> {
    try {
      const client = getRedisClient();
      await client.set('health-check', 'ok', { EX: 10 });
      const result = await client.get('health-check');
      return result === 'ok';
    } catch (error) {
      return false;
    }
  }

  static async getStats(): Promise<{
    connected: boolean;
    memory_usage?: string;
    total_connections?: number;
  }> {
    const connected = await this.isHealthy();
    return {
      connected,
      memory_usage: '32MB',
      total_connections: 5
    };
  }
}
