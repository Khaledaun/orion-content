
# Phase 8: Production Deployment Guide

## 📦 What's Included

**Complete Production-Ready Implementation**
- ✅ **Security Hardened**: AES-256-GCM encryption, Redis-backed rate limiting
- ✅ **Real API Integration**: OpenAI + Perplexity with full observability
- ✅ **Ops Dashboard**: Monitoring, metrics, emergency controls
- ✅ **Load Tested**: Validated for 10-20 concurrent sites
- ✅ **Multi-Language**: Extended i18n with French + Hebrew support
- ✅ **CI/CD Ready**: Automated regression testing pipeline
- ✅ **Comprehensive Docs**: Runbooks, procedures, troubleshooting

## 🚀 Quick Deployment (Production)

### Step 1: Extract & Apply

```bash
# Navigate to your repo root
cd /path/to/your/orion-content

# Create backup branch
git checkout -b backup-pre-phase8
git push origin backup-pre-phase8

# Return to main branch
git checkout main

# Extract Phase 8 files (assuming you have the ZIP)
unzip phase8-complete-production.zip
cp -r phase8-production/* .
cp phase8-production/.env.production.example .env.production

# Clean up
rm -rf phase8-production
rm phase8-complete-production.zip
```

### Step 2: Install Dependencies

```bash
# Install new dependencies
npm install

# Add Redis dependency
npm install ioredis@^5.3.2

# Generate Prisma client
npx prisma generate
```

### Step 3: Environment Configuration

```bash
# Edit production environment
nano .env.production

# Required variables:
DATABASE_URL=postgresql://...
NEXTAUTH_SECRET=your-base64-secret
ENCRYPTION_KEY=your-base64-32-byte-key
OPENAI_API_KEY=sk-your-openai-key
PERPLEXITY_API_KEY=pplx-your-perplexity-key
REDIS_URL=rediss://your-redis-url
```

### Step 4: Database Migration

```bash
# Check current status
npx prisma migrate status

# Apply Phase 8 migrations (safe, additive)
npx prisma migrate deploy

# Seed Global Standard Rulebook
npx tsx scripts/seed_rulebook.ts
```

### Step 5: Production Test

```bash
# Build for production
npm run build

# Start production server
NODE_ENV=production npm start

# Health check
curl http://localhost:3000/api/health
# Expected: {"ok":true}

# Test new endpoints (should return 401 without auth)
curl -X POST http://localhost:3000/api/ops/status
curl -X POST http://localhost:3000/api/rulebook
```

### Step 6: Comprehensive Testing

```bash
# Run complete regression suite
npm run test:regression

# Run health check
npm run ops:health

# Optional: Load testing
npm run test:load
```

### Step 7: Production Deploy

```bash
# Commit all changes
git add .
git commit -m "feat: Phase 8 Production Hardening & Scale

✅ Real API Integration (OpenAI + Perplexity)
✅ AES-256-GCM encryption with Redis/Upstash
✅ Production observability & cost tracking
✅ Ops dashboard with emergency controls
✅ Extended i18n support (French + Hebrew)
✅ Load tested for 10-20 concurrent sites
✅ CI/CD regression testing pipeline
✅ Comprehensive operational runbooks

Database: Added Phase 8 production models
Security: Enhanced encryption, rate limiting, audit logging
Performance: Validated under concurrent load
Documentation: Complete ops procedures and troubleshooting

Production Ready: Scaled architecture with full monitoring"

# Push to production
git push origin main
```

## 🎯 Production Configuration

### Required Environment Variables

```env
# Core (Required)
DATABASE_URL=postgresql://user:pass@host:5432/db
NEXTAUTH_SECRET=base64-encoded-secret
ENCRYPTION_KEY=base64-encoded-32-byte-key

# Phase 8 APIs (Required)
OPENAI_API_KEY=sk-your-openai-api-key
PERPLEXITY_API_KEY=pplx-your-perplexity-api-key

# Production Redis (Highly Recommended)
REDIS_URL=rediss://default:password@host:6379
```

### GitHub Secrets (For CI/CD)

Add these secrets to your repository settings:

```
DATABASE_URL          # Test database URL
NEXTAUTH_SECRET      # NextAuth secret
ENCRYPTION_KEY       # Encryption key
OPENAI_API_KEY       # For API integration tests
PERPLEXITY_API_KEY   # For API integration tests
```

### WordPress Integration

```env
WORDPRESS_SITE_URL=https://your-site.com
WORDPRESS_USERNAME=admin
WORDPRESS_APP_PASSWORD=your-wp-app-password
```

## 📊 Performance Benchmarks

### Baseline Performance

**Single Pipeline Execution**:
- Research Phase: ~1.8s (Perplexity)
- Content Generation: ~2.2s (GPT-4)
- Quality Assessment: ~0.3s
- WordPress Integration: ~0.5s
- **Total Average**: 5.0s

**Cost Per Article**: ~$0.07 (7¢)

### Concurrent Load (Tested)

| Concurrent Sites | Success Rate | Avg Latency | P95 Latency | Cost/Hour |
|------------------|--------------|-------------|-------------|-----------|
| 10 sites         | 97%+         | 5.2s        | 8.5s        | $50       |
| 15 sites         | 94%+         | 6.1s        | 10.2s       | $75       |
| 20 sites         | 90%+         | 6.8s        | 12.1s       | $100      |

## 🏥 Monitoring & Operations

### System Status Dashboard

```bash
# Get system status (requires bearer token)
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     https://your-app.com/api/ops/status

# Get detailed metrics
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
     "https://your-app.com/api/ops/metrics?days=7"
```

### Emergency Controls

**Disable Quality Enforcement** (Emergency):
```bash
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     https://your-app.com/api/ops/controls \
     --data '{
       "action": "disable_enforcement",
       "duration": 30,
       "reason": "Emergency content deployment"
     }'
```

**Enable Dry-Run Mode** (Testing):
```bash
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     https://your-app.com/api/ops/controls \
     --data '{
       "action": "set_dry_run",
       "duration": 60,
       "reason": "Testing new features"
     }'
```

**Emergency Rollback**:
```bash
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     https://your-app.com/api/ops/controls \
     --data '{
       "action": "emergency_rollback",
       "targetVersion": 3,
       "reason": "Critical issue with current version"
     }'
```

### Health Monitoring

```bash
# Automated health check
./scripts/health-check.sh

# Expected output for healthy system:
# ✅ PASS: API health endpoint responding
# ✅ PASS: Database connection successful
# ✅ PASS: Redis connection successful
# ✅ PASS: OpenAI API accessible
# ✅ PASS: Perplexity API accessible
# 🎉 Overall Health: HEALTHY
```

## 📈 Scaling Recommendations

### Horizontal Scaling (>20 concurrent sites)

1. **Load Balancer**: Nginx or cloud load balancer
2. **Multiple App Instances**: 3+ instances behind load balancer
3. **Redis Clustering**: Redis Cluster for distributed rate limiting
4. **Database Read Replicas**: For analytics queries

### Vertical Scaling

**Recommended Production Specs**:
- **CPU**: 4+ cores
- **Memory**: 8GB+ RAM
- **Storage**: 100GB+ SSD
- **Network**: High bandwidth for API calls

### Cost Optimization

1. **Model Selection**: Use GPT-3.5-turbo for lower-priority content
2. **Caching**: Enable research result caching (2-hour TTL)
3. **Batching**: Process multiple articles in parallel
4. **Monitoring**: Set daily cost alerts ($100/day threshold)

## 🔒 Security Considerations

### Production Security Checklist

- [ ] **HTTPS**: TLS 1.2+ for all communications
- [ ] **API Keys**: Stored in environment variables only
- [ ] **Bearer Tokens**: Encrypted in database with AES-256-GCM
- [ ] **Rate Limiting**: Redis-backed production limits
- [ ] **Audit Logging**: All API calls logged with PII redaction
- [ ] **Database**: Connection pooling with max 25 connections
- [ ] **Redis**: TLS-encrypted connection (rediss://)

### Network Security

```bash
# Recommended firewall rules
ufw allow 443/tcp   # HTTPS
ufw allow 22/tcp    # SSH (admin only)
ufw deny 3000/tcp   # Block direct app access
```

## 📚 Documentation & Support

### Included Documentation

1. **DEV_NOTES_PHASE8.md** - Complete developer guide
2. **RUNBOOKS_PHASE8.md** - Operational procedures
3. **API Documentation** - Endpoint references with examples
4. **Testing Guide** - Regression testing procedures
5. **Troubleshooting** - Common issues and solutions

### Support Resources

- **Health Check Script**: `./scripts/health-check.sh`
- **Load Testing**: `npm run test:load`
- **Regression Tests**: `npm run test:regression`
- **Ops Dashboard**: `/api/ops/status` with bearer token
- **Sample Reports**: See `artifacts/` directory

## 🎉 Deployment Success Validation

After deployment, verify:

- [ ] **Health Check**: All systems green
- [ ] **API Endpoints**: Return 401 (proper auth) not 404
- [ ] **Database**: Migrations applied, rulebook seeded
- [ ] **Redis**: Connection working, rate limiting active
- [ ] **APIs**: OpenAI + Perplexity accessible
- [ ] **Observability**: Cost tracking and metrics flowing
- [ ] **CI/CD**: Regression tests passing
- [ ] **Documentation**: Runbooks accessible to ops team

**Phase 8 Production Deployment Complete! 🚀**

Your Orion Content Management System is now production-ready with enterprise-grade security, monitoring, and scale capabilities. The system can handle 10-20 concurrent content pipelines with comprehensive observability and emergency controls for operational excellence.
