
import { NextRequest, NextResponse } from 'next/server'
import { requireBearerToken } from '@/lib/enhanced-auth'
import { getCostMetrics, getObservabilityReports } from '@/lib/observability-prod'
import { getAuditLogger } from '@/lib/audit-prod'

export const dynamic = 'force-dynamic'

interface MetricsQuery {
  days?: number
  siteId?: string
  groupBy?: 'hour' | 'day' | 'site' | 'model'
}

export async function GET(request: NextRequest) {
  try {
    const user = await requireBearerToken(request, {
      role: 'admin',
      rateLimitConfig: { windowMs: 60000, limit: 60 } // 60 requests per minute
    })

    const { searchParams } = new URL(request.url)
    const query: MetricsQuery = {
      days: parseInt(searchParams.get('days') || '7'),
      siteId: searchParams.get('siteId') || undefined,
      groupBy: (searchParams.get('groupBy') as any) || 'day'
    }

    const auditLogger = getAuditLogger()
    await auditLogger.log({
      route: '/api/ops/metrics',
      actor: user.email,
      action: 'metrics_requested',
      metadata: query
    })

    const metrics = await getDetailedMetrics(query)

    return NextResponse.json(metrics)

  } catch (error) {
    if (error instanceof NextResponse) {
      return error
    }
    
    console.error('Ops metrics error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

async function getDetailedMetrics(query: MetricsQuery) {
  const costMetrics = await getCostMetrics(query.days || 7)
  const reports = await getObservabilityReports(query.siteId, 1000)
  
  // Filter reports by time range
  const cutoffDate = new Date()
  cutoffDate.setDate(cutoffDate.getDate() - (query.days || 7))
  
  const filteredReports = reports.filter(r => 
    new Date(r.createdAt) > cutoffDate
  )

  const metrics = {
    summary: {
      totalReports: filteredReports.length,
      totalCost: costMetrics.totalCost,
      totalTokens: costMetrics.tokenUsage,
      averageLatency: filteredReports.length > 0
        ? filteredReports.reduce((sum, r) => sum + r.totalLatencyMs, 0) / filteredReports.length
        : 0,
      successRate: filteredReports.length > 0
        ? filteredReports.filter(r => r.stages.every(s => s.success)).length / filteredReports.length
        : 1
    },
    costByProvider: costMetrics.costByProvider,
    timeSeries: generateTimeSeries(filteredReports, query.groupBy || 'day'),
    topModels: getModelUsage(filteredReports),
    qualityDistribution: getQualityDistribution(filteredReports),
    latencyPercentiles: getLatencyPercentiles(filteredReports)
  }

  return metrics
}

function generateTimeSeries(reports: any[], groupBy: string) {
  const groups: Record<string, any> = {}
  
  reports.forEach(report => {
    const date = new Date(report.createdAt)
    let key: string
    
    switch (groupBy) {
      case 'hour':
        key = `${date.toISOString().substring(0, 13)}:00:00Z`
        break
      case 'day':
        key = date.toISOString().substring(0, 10)
        break
      case 'site':
        key = report.siteId
        break
      case 'model':
        key = report.stages[0]?.model || 'unknown'
        break
      default:
        key = date.toISOString().substring(0, 10)
    }
    
    if (!groups[key]) {
      groups[key] = {
        timestamp: key,
        count: 0,
        cost: 0,
        tokens: 0,
        latency: 0,
        errors: 0
      }
    }
    
    groups[key].count++
    groups[key].cost += report.totalCostUsd
    groups[key].tokens += report.totalTokens
    groups[key].latency += report.totalLatencyMs
    
    if (report.stages.some((s: any) => !s.success)) {
      groups[key].errors++
    }
  })
  
  // Calculate averages
  Object.values(groups).forEach((group: any) => {
    group.avgLatency = group.count > 0 ? group.latency / group.count : 0
    group.errorRate = group.count > 0 ? group.errors / group.count : 0
    delete group.latency // Remove raw total
  })
  
  return Object.values(groups).sort((a: any, b: any) => 
    a.timestamp.localeCompare(b.timestamp)
  )
}

function getModelUsage(reports: any[]) {
  const modelStats: Record<string, any> = {}
  
  reports.forEach(report => {
    report.stages.forEach((stage: any) => {
      if (!modelStats[stage.model]) {
        modelStats[stage.model] = {
          model: stage.model,
          usage: 0,
          cost: 0,
          tokens: 0,
          avgLatency: 0,
          successRate: 0,
          provider: stage.provider
        }
      }
      
      modelStats[stage.model].usage++
      modelStats[stage.model].cost += stage.costUsd
      modelStats[stage.model].tokens += stage.tokensInput + stage.tokensOutput
      modelStats[stage.model].avgLatency += stage.latencyMs
      
      if (stage.success) {
        modelStats[stage.model].successRate++
      }
    })
  })
  
  // Calculate averages
  Object.values(modelStats).forEach((stats: any) => {
    stats.avgLatency = stats.usage > 0 ? stats.avgLatency / stats.usage : 0
    stats.successRate = stats.usage > 0 ? stats.successRate / stats.usage : 0
  })
  
  return Object.values(modelStats).sort((a: any, b: any) => b.usage - a.usage)
}

function getQualityDistribution(reports: any[]) {
  const distribution = {
    high: 0,    // 80-100
    medium: 0,  // 60-79
    low: 0,     // 0-59
    unscored: 0
  }
  
  reports.forEach(report => {
    if (report.qualityScore === undefined || report.qualityScore === null) {
      distribution.unscored++
    } else if (report.qualityScore >= 80) {
      distribution.high++
    } else if (report.qualityScore >= 60) {
      distribution.medium++
    } else {
      distribution.low++
    }
  })
  
  return distribution
}

function getLatencyPercentiles(reports: any[]) {
  if (reports.length === 0) {
    return { p50: 0, p90: 0, p95: 0, p99: 0 }
  }
  
  const latencies = reports.map(r => r.totalLatencyMs).sort((a, b) => a - b)
  
  return {
    p50: latencies[Math.floor(latencies.length * 0.5)],
    p90: latencies[Math.floor(latencies.length * 0.9)],
    p95: latencies[Math.floor(latencies.length * 0.95)],
    p99: latencies[Math.floor(latencies.length * 0.99)]
  }
}
