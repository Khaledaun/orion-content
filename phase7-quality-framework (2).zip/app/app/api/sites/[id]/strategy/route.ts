
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireApiAuth } from '@/lib/auth'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

// Site Strategy schema validation
const siteStrategySchema = z.object({
  site_persona: z.string().optional(),
  target_audience: z.string().optional(),
  eeat_guidelines: z.object({
    author_bio_template: z.string().optional(),
    preferred_sources: z.array(z.string()).optional(),
    tone_of_voice: z.array(z.string()).optional(),
  }).optional(),
  content_archetypes: z.array(z.object({
    name: z.string(),
    prompt_file: z.string(),
    priority: z.number().min(0).max(1),
  })).optional(),
})

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await requireApiAuth(request)
    const resolvedParams = await params
    const siteId = resolvedParams.id

    // Verify site exists
    const site = await prisma.site.findUnique({
      where: { id: siteId },
    })

    if (!site) {
      return NextResponse.json(
        { error: 'Site not found' },
        { status: 404 }
      )
    }

    // Get site strategy
    const strategy = await prisma.siteStrategy.findUnique({
      where: { siteId },
    })

    return NextResponse.json(strategy?.strategy || {})
  } catch (error) {
    console.error('Get site strategy error:', error)
    
    if (error instanceof Error && error.message.includes('Bearer')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }
    
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await requireApiAuth(request)
    const resolvedParams = await params
    const siteId = resolvedParams.id

    // Verify site exists
    const site = await prisma.site.findUnique({
      where: { id: siteId },
    })

    if (!site) {
      return NextResponse.json(
        { error: 'Site not found' },
        { status: 404 }
      )
    }

    const body = await request.json()

    // Validate strategy structure
    try {
      siteStrategySchema.parse(body)
    } catch (validationError) {
      return NextResponse.json(
        { error: 'Invalid strategy format', details: validationError },
        { status: 400 }
      )
    }

    // Upsert site strategy
    const strategy = await prisma.siteStrategy.upsert({
      where: { siteId },
      update: {
        strategy: body,
        updatedAt: new Date(),
      },
      create: {
        siteId,
        strategy: body,
      },
    })

    return NextResponse.json(strategy)
  } catch (error) {
    console.error('Update site strategy error:', error)
    
    if (error instanceof Error && error.message.includes('Bearer')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }
    
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
