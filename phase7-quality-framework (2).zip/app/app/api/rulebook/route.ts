
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireApiAuth } from '@/lib/auth'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

// Global Rulebook schema validation
const globalRulebookSchema = z.object({
  eeat: z.object({
    require_author_bio: z.boolean(),
    require_citations: z.boolean(),
    allowed_source_domains: z.array(z.string()),
    citation_style: z.string(),
    tone_constraints: z.array(z.string()),
  }).optional(),
  seo: z.object({
    title_length: z.object({
      min: z.number(),
      max: z.number(),
    }),
    meta_description: z.object({
      min: z.number(),
      max: z.number(),
    }),
    h1_rules: z.object({
      must_include_primary_keyword: z.boolean(),
    }),
    internal_links_min: z.number(),
    outbound_links_min: z.number(),
    image_alt_required: z.boolean(),
    slug_style: z.string(),
  }).optional(),
  aio: z.object({
    summary_block_required: z.boolean(),
    qa_block_required: z.boolean(),
    structured_data: z.array(z.string()),
    answers_should_be_self_contained: z.boolean(),
    content_layout: z.array(z.string()),
  }).optional(),
  ai_search_visibility: z.object({
    clear_headings: z.boolean(),
    explicit_facts_with_sources: z.boolean(),
    avoid_fluff: z.boolean(),
    scannability_score_min: z.number(),
  }).optional(),
  prohibited: z.object({
    claims_without_source: z.boolean(),
    fabricated_stats: z.boolean(),
    over_optimization_patterns: z.array(z.string()),
  }).optional(),
  score_weights: z.object({
    eeat: z.number(),
    seo: z.number(),
    aio: z.number(),
    ai_search_visibility: z.number(),
  }).optional(),
  enforcement: z.object({
    default_min_quality_score: z.number(),
    block_publish_if_below: z.boolean(),
    tag_if_below: z.string(),
  }).optional(),
})

export async function GET(request: NextRequest) {
  try {
    await requireApiAuth(request)

    // Get the latest rulebook
    const rulebook = await prisma.globalRulebook.findFirst({
      orderBy: { version: 'desc' },
    })

    if (!rulebook) {
      return NextResponse.json(
        { error: 'No rulebook found' },
        { status: 404 }
      )
    }

    return NextResponse.json(rulebook)
  } catch (error) {
    console.error('Get rulebook error:', error)
    
    if (error instanceof Error && error.message.includes('Bearer')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }
    
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    await requireApiAuth(request)

    const { rules, sources, notes } = await request.json()

    if (!rules) {
      return NextResponse.json(
        { error: 'Rules are required' },
        { status: 400 }
      )
    }

    // Validate rules structure
    try {
      globalRulebookSchema.parse(rules)
    } catch (validationError) {
      return NextResponse.json(
        { error: 'Invalid rulebook format', details: validationError },
        { status: 400 }
      )
    }

    // Get the current highest version
    const latestRulebook = await prisma.globalRulebook.findFirst({
      orderBy: { version: 'desc' },
    })

    const newVersion = (latestRulebook?.version || 0) + 1

    // Create new rulebook version (current active one)
    const newRulebook = await prisma.globalRulebook.create({
      data: {
        version: newVersion,
        rules,
        sources: sources || [],
        updatedBy: 'admin',
      },
    })

    // Also append to version history
    await prisma.rulebookVersion.create({
      data: {
        version: newVersion,
        rules,
        sources: sources || [],
        notes: notes || `Version ${newVersion} created`,
      },
    })

    return NextResponse.json(newRulebook)
  } catch (error) {
    console.error('Create rulebook error:', error)
    
    if (error instanceof Error && error.message.includes('Bearer')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }
    
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
