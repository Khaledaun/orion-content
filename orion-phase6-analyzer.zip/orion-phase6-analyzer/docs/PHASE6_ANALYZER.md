
# Phase 6: Strategic Site Analyzer

This documentation covers the **Strategic Site Analyzer** module that provides multi-mode intelligence for site analysis across three distinct strategic use cases.

## Overview

Phase 6 introduces a comprehensive site analysis system with three specialized modes:

- ✅ **my-site**: Technical SEO audit, blueprint generation, and internal linking analysis for your own sites
- ✅ **competitor**: Competitive intelligence, content strategy analysis, and opportunity identification
- ✅ **prospect**: Sales and lead generation reports with email-ready proposals

## Architecture

```
┌─────────────────────┐    ┌─────────────────────┐    ┌─────────────────────┐
│   CLI Interface     │    │   Site Analyzer     │    │   Analysis Modes    │
│  (run_analyzer.py)  │───▶│   (analyzer.py)     │───▶│  my-site/competitor │
└─────────────────────┘    └─────────────────────┘    │     /prospect       │
                                      │                └─────────────────────┘
                                      ▼                           │
                           ┌─────────────────────┐                ▼
                           │  Site Crawler       │    ┌─────────────────────┐
                           │  (BeautifulSoup)    │───▶│   JSON Reports      │
                           └─────────────────────┘    │  + Email Templates  │
                                                     └─────────────────────┘
```

## Installation & Setup

### Prerequisites

The analyzer is part of the Orion Content system under `python/orion/analyze/`:

```
python/orion/analyze/
├── __init__.py
├── analyzer.py          # Core analysis logic
└── run_analyzer.py      # CLI interface
```

### Dependencies

All required dependencies are included in the main Orion `requirements.txt`:
- `requests` - Web crawling
- `beautifulsoup4` - HTML parsing
- `urllib3` - URL handling

### Basic Installation

```Bash Terminal
# Navigate to your Orion project
cd /path/to/orion-content

# Ensure Python environment is activated
source python/.venv/bin/activate  # or your virtual environment

# Install/update dependencies
pip install -r python/requirements.txt

# Test the analyzer
PYTHONPATH=python python -m orion.analyze.run_analyzer --help
```

## CLI Usage

### Basic Command Structure

```Bash Terminal
python -m orion.analyze.run_analyzer --url <TARGET_URL> --mode <ANALYSIS_MODE> [OPTIONS]
```

### Analysis Modes

#### **Mode 1: my-site** (Self-Audit & Blueprinting)

```Bash Terminal
# Basic self-audit
python -m orion.analyze.run_analyzer --url https://mysite.com --mode my-site

# With custom output directory
python -m orion.analyze.run_analyzer --url https://mysite.com --mode my-site --output ./site-audits/

# Limit crawling (faster analysis)
python -m orion.analyze.run_analyzer --url https://mysite.com --mode my-site --max-pages 25
```

**What it analyzes:**
- **Technical SEO Audit**: Duplicate titles, missing meta descriptions, title lengths, H1 keyword analysis
- **Site Blueprint**: Content archetypes, target audience, tone of voice, strategy recommendations
- **Internal Linking**: Identifies orphan pages and linking opportunities

#### **Mode 2: competitor** (Competitive Intelligence)

```Bash Terminal
# Competitor analysis
python -m orion.analyze.run_analyzer --url https://competitor.com --mode competitor

# Detailed competitive intelligence
python -m orion.analyze.run_analyzer --url https://competitor.com --mode competitor --max-pages 50 --verbose
```

**What it analyzes:**
- **Content Strategy**: Primary content formats, topical clusters, tone of voice
- **SEO Keyword Strategy**: Target keywords, keyword density patterns, long-tail usage
- **Strategic Opportunities**: Content gaps, format gaps, depth advantages

#### **Mode 3: prospect** (Sales & Lead Generation)

```Bash Terminal
# Prospect analysis
python -m orion.analyze.run_analyzer --url https://prospect.com --mode prospect

# Generate summary format for quick review
python -m orion.analyze.run_analyzer --url https://prospect.com --mode prospect --format summary
```

**What it generates:**
- **Missed Opportunities Audit**: 5 clear, actionable SEO and content weaknesses
- **Mini-Proposal**: Email-ready summary with call-to-action
- **Business Impact Analysis**: Professional assessment of potential improvements

### Command Line Options

```Bash Terminal
# Core Options
--url URL               # Target website URL (required)
--mode {my-site,competitor,prospect}  # Analysis mode (required)

# Output Options  
--output DIR           # Output directory (default: ./analysis-reports/)
--format {json,summary} # Output format (default: json)

# Analysis Options
--max-pages N          # Maximum pages to crawl (default: 50)
--use-llm             # Enable LLM-powered analysis (requires API keys)
--verbose, -v         # Enable verbose logging

# Examples
python -m orion.analyze.run_analyzer --url https://example.com --mode my-site --verbose
python -m orion.analyze.run_analyzer --url https://competitor.com --mode competitor --max-pages 30
python -m orion.analyze.run_analyzer --url https://prospect.com --mode prospect --format summary
```

## Output Formats

### JSON Reports

All analyses generate structured JSON reports with the naming convention:
```
analysis-report-{mode}-{domain}.json
```

**Example filenames:**
- `analysis-report-my-site-mywebsite_com.json`
- `analysis-report-competitor-competitor_com.json`
- `analysis-report-prospect-prospect_com.json`

### JSON Structure

```json
{
  "mode": "my-site",
  "domain": "example.com",
  "timestamp": "2024-08-28T14:30:00Z",
  "summary": {
    "total_pages_analyzed": 15,
    "seo_score": 75,
    "technical_issues_found": 3,
    "orphan_pages_identified": 2,
    "site_category": "Business & Finance",
    "content_archetypes": 3
  },
  "recommendations": [
    {
      "category": "Technical SEO",
      "priority": "high",
      "title": "Fix Missing Meta Descriptions",
      "description": "5 pages are missing meta descriptions",
      "action_items": [
        "Add unique meta descriptions to all pages",
        "Keep descriptions between 150-160 characters",
        "Include target keywords naturally"
      ]
    }
  ],
  "metadata": {
    "analysis_type": "comprehensive_audit",
    "crawl_depth": {"max_pages_limit": 50, "actual_pages_crawled": 15},
    "blueprint_generated": true,
    "seo_audit_completed": true,
    "linking_analysis_completed": true
  },
  "raw_data": {
    "seo_audit": { /* Detailed SEO analysis */ },
    "site_blueprint": { /* Site strategy data */ },
    "linking_opportunities": { /* Internal linking analysis */ }
  }
}
```

## Analysis Mode Details

### **my-site Mode**: Technical SEO & Strategy

#### Technical SEO Audit

**Identifies:**
- Duplicate title tags across pages
- Missing meta descriptions
- Title length issues (too long/short)
- Top 10 H1 keywords analysis
- SEO score calculation (0-100)

**Sample Output:**
```json
{
  "seo_audit": {
    "score": 75,
    "issues": [
      {
        "title": "Duplicate Title Tags",
        "description": "Found 3 duplicate title tags",
        "severity": "high",
        "action_items": [
          "Review and rewrite duplicate title tags",
          "Ensure each page has a unique, descriptive title"
        ]
      }
    ],
    "top_h1_keywords": [
      ["marketing", 5],
      ["business", 3],
      ["guide", 2]
    ],
    "statistics": {
      "total_pages": 15,
      "pages_with_titles": 15,
      "pages_with_meta_descriptions": 12,
      "unique_titles": 12,
      "average_title_length": 52.3
    }
  }
}
```

#### Site Blueprint Generation

**Creates:**
- Site category classification
- Content archetype identification
- Target audience analysis
- Tone of voice assessment
- Strategy recommendations

**Sample Output:**
```json
{
  "site_blueprint": {
    "category": "Business & Finance",
    "content_archetypes": [
      "How-to Guides",
      "Reviews & Comparisons", 
      "Tips & Lists"
    ],
    "persona": "Professional",
    "target_audience": "Business professionals",
    "tone_of_voice": "Informative",
    "strategy_recommendations": [
      "Focus on comprehensive guides",
      "Build topical authority in core areas",
      "Improve internal linking structure"
    ]
  }
}
```

#### Internal Linking Analysis

**Identifies:**
- Orphan pages (pages with few internal links)
- Internal linking opportunities
- Link distribution patterns

**Sample Output:**
```json
{
  "linking_opportunities": {
    "orphan_pages": [
      {
        "url": "https://mysite.com/hidden-guide",
        "title": "Hidden Guide to Advanced Strategies",
        "internal_link_count": 0,
        "word_count": 1200
      }
    ],
    "total_internal_links": 45,
    "pages_analyzed": 15,
    "linking_recommendations": [
      "Create hub pages that link to related content",
      "Add contextual internal links within content"
    ]
  }
}
```

### **competitor Mode**: Intelligence & Opportunities

#### Content Strategy Analysis

**Analyzes:**
- Primary content formats (how-to, reviews, listicles, etc.)
- Topical clusters and focus areas
- Tone of voice assessment
- Content volume and average length

**Sample Output:**
```json
{
  "content_strategy": {
    "primary_formats": [
      "How-to Guides",
      "Reviews", 
      "Listicles"
    ],
    "topical_clusters": [
      "Marketing",
      "Business",
      "Technology"
    ],
    "tone_of_voice": "Professional",
    "content_volume": 25,
    "average_content_length": 1250
  }
}
```

#### SEO Keyword Strategy

**Identifies:**
- Target keywords from titles and H1s
- Keyword density patterns
- Long-tail keyword usage

**Sample Output:**
```json
{
  "keyword_strategy": {
    "target_keywords": [
      ["marketing", 8],
      ["business", 6],
      ["strategy", 4],
      ["growth", 3],
      ["guide", 3]
    ],
    "keyword_density_patterns": "moderate",
    "long_tail_usage": "present"
  }
}
```

#### Strategic Opportunities

**Finds:**
- Limited topical authority gaps
- Content format opportunities  
- Content depth advantages
- Specific action items for each opportunity

**Sample Output:**
```json
{
  "strategic_opportunities": [
    {
      "title": "Content Format Gaps",
      "description": "Competitor is not utilizing these content formats: Case Studies, Tools & Resources",
      "type": "format_gap",
      "priority": "medium",
      "advantage": "Diversify content portfolio with underused formats",
      "action_items": [
        "Create case studies content",
        "Test different content formats for engagement",
        "Build format-specific content series"
      ]
    }
  ]
}
```

### **prospect Mode**: Sales & Lead Generation

#### Missed Opportunities Audit

**Identifies 5 Key Areas:**
- Technical SEO issues
- Limited content volume
- Weak internal link structure
- Page performance optimization
- Content depth and quality

**Sample Output:**
```json
{
  "missed_opportunities_audit": [
    {
      "title": "Technical SEO Issues",
      "description": "Your website has several technical SEO issues that could be limiting organic search visibility.",
      "business_impact"
