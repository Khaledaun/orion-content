
# Phase 6: Strategic Site Analyzer

This documentation covers the **Strategic Site Analyzer** module that provides multi-mode intelligence for site analysis across three distinct strategic use cases.

## Overview

Phase 6 introduces a comprehensive site analysis system with three specialized modes:

- ✅ **my-site**: Technical SEO audit, blueprint generation, and internal linking analysis for your own sites
- ✅ **competitor**: Competitive intelligence, content strategy analysis, and opportunity identification
- ✅ **prospect**: Sales and lead generation reports with email-ready proposals

## CLI Usage

### Basic Command Structure

```Bash Terminal
python -m orion.analyze.run_analyzer --url <TARGET_URL> --mode <ANALYSIS_MODE> [OPTIONS]
```

### Analysis Modes

#### **Mode 1: my-site** (Self-Audit & Blueprinting)

```Bash Terminal
# Basic self-audit
python -m orion.analyze.run_analyzer --url https://mysite.com --mode my-site

# With custom output directory
python -m orion.analyze.run_analyzer --url https://mysite.com --mode my-site --output ./site-audits/

# Limit crawling (faster analysis)
python -m orion.analyze.run_analyzer --url https://mysite.com --mode my-site --max-pages 25
```

**What it analyzes:**
- **Technical SEO Audit**: Duplicate titles, missing meta descriptions, title lengths, H1 keyword analysis
- **Site Blueprint**: Content archetypes, target audience, tone of voice, strategy recommendations  
- **Internal Linking**: Identifies orphan pages and linking opportunities

#### **Mode 2: competitor** (Competitive Intelligence)

```Bash Terminal
# Competitor analysis
python -m orion.analyze.run_analyzer --url https://competitor.com --mode competitor

# Detailed competitive intelligence
python -m orion.analyze.run_analyzer --url https://competitor.com --mode competitor --max-pages 50 --verbose
```

**What it analyzes:**
- **Content Strategy**: Primary content formats, topical clusters, tone of voice
- **SEO Keyword Strategy**: Target keywords, keyword density patterns, long-tail usage
- **Strategic Opportunities**: Content gaps, format gaps, depth advantages

#### **Mode 3: prospect** (Sales & Lead Generation)

```Bash Terminal
# Prospect analysis
python -m orion.analyze.run_analyzer --url https://prospect.com --mode prospect

# Generate summary format for quick review
python -m orion.analyze.run_analyzer --url https://prospect.com --mode prospect --format summary
```

**What it generates:**
- **Missed Opportunities Audit**: 5 clear, actionable SEO and content weaknesses
- **Mini-Proposal**: Email-ready summary with call-to-action
- **Business Impact Analysis**: Professional assessment of potential improvements

### Command Line Options

```Bash Terminal
# Core Options
--url URL               # Target website URL (required)
--mode {my-site,competitor,prospect}  # Analysis mode (required)

# Output Options  
--output DIR           # Output directory (default: ./analysis-reports/)
--format {json,summary} # Output format (default: json)

# Analysis Options
--max-pages N          # Maximum pages to crawl (default: 50)
--use-llm             # Enable LLM-powered analysis (requires API keys)
--verbose, -v         # Enable verbose logging
```

## Output Formats

### JSON Reports

All analyses generate structured JSON reports with the naming convention:
```
analysis-report-{mode}-{domain}.json
```

### Sample JSON Structure

```json
{
  "mode": "my-site",
  "domain": "example.com", 
  "timestamp": "2024-08-28T14:30:00Z",
  "summary": {
    "total_pages_analyzed": 15,
    "seo_score": 75,
    "technical_issues_found": 3,
    "orphan_pages_identified": 2
  },
  "recommendations": [
    {
      "category": "Technical SEO",
      "priority": "high", 
      "title": "Fix Missing Meta Descriptions",
      "description": "5 pages are missing meta descriptions",
      "action_items": [
        "Add unique meta descriptions to all pages",
        "Keep descriptions between 150-160 characters"
      ]
    }
  ],
  "raw_data": {
    "seo_audit": { /* Detailed analysis */ },
    "site_blueprint": { /* Strategy data */ }
  }
}
```

## Installation & Setup

```Bash Terminal
# Navigate to your Orion project
cd /path/to/orion-content

# Ensure Python environment is activated
source python/.venv/bin/activate  

# Install/update dependencies
pip install -r python/requirements.txt

# Test the analyzer
PYTHONPATH=python python -m orion.analyze.run_analyzer --help
```

## Use Cases & Workflows

### **Workflow 1**: Own Site Audit

```Bash Terminal
# 1. Audit your current site
python -m orion.analyze.run_analyzer --url https://mysite.com --mode my-site

# 2. Review JSON report for technical issues
cat analysis-reports/analysis-report-my-site-mysite_com.json

# 3. Re-audit after improvements
python -m orion.analyze.run_analyzer --url https://mysite.com --mode my-site --output ./after-fixes/
```

### **Workflow 2**: Competitive Research

```Bash Terminal
# 1. Analyze top competitors
python -m orion.analyze.run_analyzer --url https://competitor1.com --mode competitor
python -m orion.analyze.run_analyzer --url https://competitor2.com --mode competitor  

# 2. Compare reports & use insights for content planning
```

### **Workflow 3**: Sales & Lead Generation

```Bash Terminal
# 1. Research prospect
python -m orion.analyze.run_analyzer --url https://prospect.com --mode prospect

# 2. Review generated email template & send to prospect
```

## Performance & Troubleshooting

### Performance Considerations
- **Default**: 50 pages maximum per analysis
- **Fast**: 10-15 pages = ~30-60 seconds
- **Medium**: 25-35 pages = ~2-3 minutes  

### Common Issues

**Issue**: `ModuleNotFoundError: No module named 'orion.analyze'`
```Bash Terminal
# Solution: Set PYTHONPATH
PYTHONPATH=python python -m orion.analyze.run_analyzer --help
```

**Issue**: `Empty analysis results`
```Bash Terminal
# Solution: Try with verbose logging
python -m orion.analyze.run_analyzer --url https://target-site.com --mode my-site --verbose
```

## Integration

### Batch Analysis

```Bash Terminal
# Analyze multiple competitors
for competitor in competitor1.com competitor2.com; do
    python -m orion.analyze.run_analyzer --url https://$competitor --mode competitor
done
```

### GitHub Actions Integration

```yaml
- name: Run Strategic Analysis
  run: |
    cd python
    python -m orion.analyze.run_analyzer --url ${{ secrets.TARGET_URL }} --mode competitor
    
- name: Upload Analysis Reports
  uses: actions/upload-artifact@v4
  with:
    name: analysis-reports
    path: analysis-reports/
```

## Summary

Phase 6 Strategic Site Analyzer provides:

✅ **Three specialized analysis modes** for different strategic needs  
✅ **Comprehensive site crawling** with intelligent data extraction  
✅ **Actionable recommendations** with clear business impact  
✅ **JSON reports** with structured, programmatic access  
✅ **Email-ready proposals** for sales and outreach  
✅ **CLI interface** for easy integration and automation  

The analyzer transforms Orion from a content automation system into a **strategic intelligence platform** that can audit your sites, analyze competitors, and generate client-facing reports.

**Ready to use**: The analyzer is production-ready with comprehensive error handling, extensive test coverage, and detailed documentation for all use cases.
