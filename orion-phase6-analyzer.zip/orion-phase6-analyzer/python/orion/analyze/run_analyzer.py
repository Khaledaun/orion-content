
"""
CLI interface for Orion Content Site Analyzer - Phase 6.

Usage:
    python -m orion.analyze.run_analyzer --url https://example.com --mode my-site
    python -m orion.analyze.run_analyzer --url https://competitor.com --mode competitor  
    python -m orion.analyze.run_analyzer --url https://prospect.com --mode prospect
"""

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from .analyzer import SiteAnalyzer, AnalysisMode, AnalysisResult

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments."""
    
    parser = argparse.ArgumentParser(
        description='Orion Content Site Analyzer - Strategic Intelligence Tool',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Analysis Modes:
  my-site     - Self-audit and blueprinting for your own sites
                Includes technical SEO audit, blueprint generation, and internal linking analysis
                
  competitor  - Competitive intelligence and gap analysis
                Analyzes content strategy, keyword targeting, and identifies opportunities
                
  prospect    - Sales and lead generation reports
                Creates missed opportunities audit and email-ready proposal

Examples:
  # Analyze your own site for SEO and strategy insights
  python -m orion.analyze.run_analyzer --url https://mysite.com --mode my-site
  
  # Perform competitive analysis
  python -m orion.analyze.run_analyzer --url https://competitor.com --mode competitor
  
  # Generate a prospect report for sales outreach
  python -m orion.analyze.run_analyzer --url https://prospect.com --mode prospect
  
  # Analyze with custom output directory
  python -m orion.analyze.run_analyzer --url https://example.com --mode my-site --output ./reports/
  
  # Limit crawling to specific number of pages
  python -m orion.analyze.run_analyzer --url https://example.com --mode competitor --max-pages 25
        """
    )
    
    parser.add_argument(
        '--url',
        required=True,
        help='Target website URL to analyze'
    )
    
    parser.add_argument(
        '--mode',
        required=True,
        choices=['my-site', 'competitor', 'prospect'],
        help='Analysis mode: my-site (self-audit), competitor (intelligence), prospect (lead gen)'
    )
    
    parser.add_argument(
        '--output',
        default='./analysis-reports/',
        help='Output directory for analysis reports (default: ./analysis-reports/)'
    )
    
    parser.add_argument(
        '--max-pages',
        type=int,
        default=50,
        help='Maximum number of pages to crawl (default: 50)'
    )
    
    parser.add_argument(
        '--use-llm',
        action='store_true',
        default=False,
        help='Use LLM for enhanced analysis (requires API keys)'
    )
    
    parser.add_argument(
        '--verbose',
        '-v',
        action='store_true',
        help='Enable verbose logging'
    )
    
    parser.add_argument(
        '--format',
        choices=['json', 'summary'],
        default='json',
        help='Output format (default: json)'
    )
    
    return parser.parse_args()


def validate_url(url: str) -> bool:
    """Validate URL format."""
    
    try:
        parsed = urlparse(url)
        return bool(parsed.netloc and parsed.scheme in ['http', 'https'])
    except Exception:
        return False


def get_domain_from_url(url: str) -> str:
    """Extract domain name from URL for filename."""
    
    try:
        parsed = urlparse(url)
        domain = parsed.netloc
        # Remove www. prefix if present
        if domain.startswith('www.'):
            domain = domain[4:]
        # Replace dots and other special characters with underscores
        domain = domain.replace('.', '_').replace(':', '_').replace('/', '_')
        return domain
    except Exception:
        return 'unknown_domain'


def save_analysis_result(result: AnalysisResult, output_dir: str, format_type: str = 'json') -> str:
    """Save analysis result to file."""
    
    # Create output directory
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Generate filename
    domain = get_domain_from_url(result.domain)
    filename = f"analysis-report-{result.mode}-{domain}.json"
    filepath = output_path / filename
    
    try:
        if format_type == 'json':
            # Convert dataclass to dict for JSON serialization
            result_dict = {
                'mode': result.mode,
                'domain': result.domain,
                'timestamp': result.timestamp,
                'summary': result.summary,
                'recommendations': result.recommendations,
                'metadata': result.metadata,
                'raw_data': result.raw_data
            }
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(result_dict, f, indent=2, ensure_ascii=False)
        
        elif format_type == 'summary':
            # Create human-readable summary
            with open(filepath.with_suffix('.txt'), 'w', encoding='utf-8') as f:
                f.write(f"Orion Content Analysis Report\n")
                f.write(f"{'='*40}\n\n")
                f.write(f"Domain: {result.domain}\n")
                f.write(f"Mode: {result.mode}\n")
                f.write(f"Timestamp: {result.timestamp}\n\n")
                
                f.write(f"Summary:\n")
                for key, value in result.summary.items():
                    f.write(f"  {key}: {value}\n")
                
                f.write(f"\nRecommendations ({len(result.recommendations)}):\n")
                for i, rec in enumerate(result.recommendations, 1):
                    f.write(f"\n{i}. {rec.get('title', 'Untitled')}\n")
                    f.write(f"   Category: {rec.get('category', 'N/A')}\n")
                    f.write(f"   Priority: {rec.get('priority', 'N/A')}\n")
                    f.write(f"   Description: {rec.get('description', 'N/A')}\n")
            
            filepath = filepath.with_suffix('.txt')
        
        return str(filepath)
        
    except Exception as e:
        logger.error(f"Failed to save analysis result: {e}")
        return ""


def print_summary(result: AnalysisResult) -> None:
    """Print a summary of the analysis result."""
    
    print(f"\n{'='*60}")
    print(f"ORION CONTENT ANALYSIS COMPLETE")
    print(f"{'='*60}")
    print(f"Domain: {result.domain}")
    print(f"Mode: {result.mode.upper()}")
    print(f"Analysis Time: {result.timestamp}")
    
    print(f"\nSUMMARY:")
    for key, value in result.summary.items():
        if not isinstance(value, (dict, list)):
            print(f"  {key.replace('_', ' ').title()}: {value}")
    
    print(f"\nRECOMMENDATIONS ({len(result.recommendations)}):")
    for i, rec in enumerate(result.recommendations[:5], 1):  # Show top 5
        print(f"  {i}. [{rec.get('priority', 'N/A').upper()}] {rec.get('title', 'Untitled')}")
    
    if len(result.recommendations) > 5:
        print(f"  ... and {len(result.recommendations) - 5} more recommendations")
    
    # Mode-specific additional info
    if result.mode == 'prospect' and result.raw_data and 'mini_proposal' in result.raw_data:
        proposal = result.raw_data['mini_proposal']
        print(f"\nPROSPECT REPORT:")
        print(f"  Audit Score: {proposal.get('audit_score', 'N/A')}")
        print(f"  Email template ready for client outreach")
    
    elif result.mode == 'competitor' and result.raw_data:
        content_strategy = result.raw_data.get('content_strategy', {})
        print(f"\nCOMPETITOR INSIGHTS:")
        if content_strategy.get('primary_formats'):
            print(f"  Primary Content Formats: {', '.join(content_strategy['primary_formats'])}")
        if content_strategy.get('topical_clusters'):
            print(f"  Topical Clusters: {', '.join(content_strategy['topical_clusters'])}")
    
    elif result.mode == 'my-site' and result.raw_data:
        seo_audit = result.raw_data.get('seo_audit', {})
        print(f"\nSITE AUDIT:")
        print(f"  SEO Score: {seo_audit.get('score', 'N/A')}/100")
        if seo_audit.get('issues'):
            print(f"  Issues Found: {len(seo_audit['issues'])}")


def main() -> int:
    """Main CLI entry point."""
    
    try:
        args = parse_arguments()
        
        # Configure logging
        if args.verbose:
            logging.getLogger().setLevel(logging.DEBUG)
        
        # Validate URL
        if not validate_url(args.url):
            logger.error(f"Invalid URL format: {args.url}")
            return 1
        
        logger.info(f"Starting analysis of {args.url} in {args.mode} mode")
        
        # Create analyzer
        analyzer = SiteAnalyzer(
            use_llm=args.use_llm,
            max_pages=args.max_pages
        )
        
        # Run analysis
        mode = AnalysisMode(args.mode)
        result = analyzer.analyze_site(args.url, mode)
        
        # Check for errors
        if result.summary.get('error'):
            logger.error(f"Analysis failed: {result.summary.get('error_message', 'Unknown error')}")
            return 1
        
        # Save result
        output_file = save_analysis_result(result, args.output, args.format)
        
        if output_file:
            logger.info(f"Analysis report saved: {output_file}")
        else:
            logger.error("Failed to save analysis report")
        
        # Print summary
        print_summary(result)
        
        # Mode-specific output
        if args.mode == 'prospect' and result.raw_data and 'mini_proposal' in result.raw_data:
            email_template = result.raw_data['mini_proposal'].get('email_template', '')
            if email_template:
                print(f"\n{'='*60}")
                print("EMAIL TEMPLATE (Ready for client outreach):")
                print(f"{'='*60}")
                print(email_template)
        
        logger.info("Analysis completed successfully")
        return 0
        
    except KeyboardInterrupt:
        logger.info("Analysis interrupted by user")
        return 130
        
    except Exception as e:
        logger.error(f"Analysis failed with error: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())


