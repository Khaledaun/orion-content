
"""
Core site analysis logic for Orion Content System - Phase 6.

Provides strategic analysis across three modes:
- my-site: Technical SEO audit, blueprint generation, internal linking
- competitor: Strategy analysis, keyword research, opportunity identification  
- prospect: Missed opportunities audit, mini-proposal generation
"""

import logging
import re
import json
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Any, Optional, Tuple
from urllib.parse import urlparse
from dataclasses import dataclass, asdict

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


class AnalysisMode(Enum):
    """Analysis modes for site analyzer."""
    MY_SITE = "my-site"
    COMPETITOR = "competitor" 
    PROSPECT = "prospect"


@dataclass
class PageData:
    """Structured data for a single page."""
    url: str
    title: str
    meta_description: str
    h1_tags: List[str]
    h2_tags: List[str]
    word_count: int
    internal_links: List[str]
    external_links: List[str]


@dataclass
class SiteData:
    """Complete site analysis data."""
    domain: str
    base_url: str
    total_pages: int
    pages: List[PageData]
    crawl_timestamp: str
    analysis_metadata: Dict[str, Any]


@dataclass
class AnalysisResult:
    """Structured analysis result."""
    mode: str
    domain: str
    timestamp: str
    summary: Dict[str, Any]
    recommendations: List[Dict[str, Any]]
    metadata: Dict[str, Any]
    raw_data: Optional[Dict[str, Any]] = None


class SiteAnalyzer:
    """Multi-mode strategic site analyzer."""
    
    def __init__(self, use_llm: bool = True, max_pages: int = 50):
        self.use_llm = use_llm
        self.max_pages = max_pages
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Orion Content Analyzer/1.0 (Strategic Analysis Bot)'
        })
    
    def analyze_site(self, url: str, mode: AnalysisMode) -> AnalysisResult:
        """
        Main analysis entry point.
        
        Args:
            url: Target website URL
            mode: Analysis mode (my-site, competitor, prospect)
            
        Returns:
            AnalysisResult with mode-specific analysis
        """
        
        logger.info(f"Starting {mode.value} analysis for {url}")
        
        try:
            # Step 1: Crawl and parse site data
            site_data = self._crawl_site(url)
            
            # Step 2: Perform mode-specific analysis
            if mode == AnalysisMode.MY_SITE:
                result = self._analyze_my_site(site_data)
            elif mode == AnalysisMode.COMPETITOR:
                result = self._analyze_competitor(site_data)
            elif mode == AnalysisMode.PROSPECT:
                result = self._analyze_prospect(site_data)
            else:
                raise ValueError(f"Unsupported analysis mode: {mode}")
            
            logger.info(f"Analysis completed for {url} in {mode.value} mode")
            return result
            
        except Exception as e:
            logger.error(f"Analysis failed for {url}: {e}")
            return self._create_error_result(url, mode, str(e))
    
    def _crawl_site(self, url: str) -> SiteData:
        """
        Crawl site to gather page data.
        
        Args:
            url: Target website URL
            
        Returns:
            SiteData with crawled information
        """
        
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        
        logger.info(f"Crawling site: {domain} (max {self.max_pages} pages)")
        
        # Start with homepage
        pages_to_crawl = [url]
        crawled_urls = set()
        pages_data = []
        
        while pages_to_crawl and len(crawled_urls) < self.max_pages:
            current_url = pages_to_crawl.pop(0)
            
            if current_url in crawled_urls:
                continue
                
            try:
                page_data = self._crawl_page(current_url, base_url)
                if page_data:
                    pages_data.append(page_data)
                    crawled_urls.add(current_url)
                    
                    # Add internal links for further crawling
                    for link in page_data.internal_links:
                        if link not in crawled_urls and link not in pages_to_crawl:
                            pages_to_crawl.append(link)
                            
            except Exception as e:
                logger.warning(f"Failed to crawl {current_url}: {e}")
                continue
        
        return SiteData(
            domain=domain,
            base_url=base_url,
            total_pages=len(pages_data),
            pages=pages_data,
            crawl_timestamp=datetime.now(timezone.utc).isoformat(),
            analysis_metadata={
                'max_pages_limit': self.max_pages,
                'actual_pages_crawled': len(pages_data),
                'crawl_depth': 'automatic'
            }
        )
    
    def _crawl_page(self, url: str, base_url: str) -> Optional[PageData]:
        """
        Crawl a single page and extract structured data.
        
        Args:
            url: Page URL to crawl
            base_url: Base URL of the site
            
        Returns:
            PageData or None if crawling failed
        """
        
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract title
            title_tag = soup.find('title')
            title = title_tag.get_text().strip() if title_tag else ""
            
            # Extract meta description
            meta_desc_tag = soup.find('meta', attrs={'name': 'description'})
            meta_description = meta_desc_tag.get('content', '').strip() if meta_desc_tag else ""
            
            # Extract H1 and H2 tags
            h1_tags = [h1.get_text().strip() for h1 in soup.find_all('h1')]
            h2_tags = [h2.get_text().strip() for h2 in soup.find_all('h2')]
            
            # Calculate word count (approximate)
            text_content = soup.get_text()
            word_count = len(text_content.split()) if text_content else 0
            
            # Extract links
            internal_links = []
            external_links = []
            
            for link in soup.find_all('a', href=True):
                href = link['href']
                if href.startswith('http'):
                    if base_url in href:
                        internal_links.append(href)
                    else:
                        external_links.append(href)
                elif href.startswith('/'):
                    internal_links.append(f"{base_url}{href}")
            
            return PageData(
                url=url,
                title=title,
                meta_description=meta_description,
                h1_tags=h1_tags,
                h2_tags=h2_tags,
                word_count=word_count,
                internal_links=list(set(internal_links)),  # Remove duplicates
                external_links=list(set(external_links))
            )
            
        except Exception as e:
            logger.warning(f"Failed to crawl page {url}: {e}")
            return None
    
    def _analyze_my_site(self, site_data: SiteData) -> AnalysisResult:
        """
        Analyze own site for SEO audit, blueprint, and internal linking.
        
        Args:
            site_data: Crawled site data
            
        Returns:
            AnalysisResult with my-site analysis
        """
        
        logger.info(f"Performing my-site analysis for {site_data.domain}")
        
        # Technical SEO Audit
        seo_audit = self._perform_technical_seo_audit(site_data)
        
        # Blueprint Generation
        site_blueprint = self._generate_site_blueprint(site_data)
        
        # Internal Linking Analysis
        linking_opportunities = self._analyze_internal_linking(site_data)
        
        # Compile recommendations
        recommendations = []
        
        # SEO recommendations
        if seo_audit['issues']:
            for issue in seo_audit['issues']:
                recommendations.append({
                    'category': 'Technical SEO',
                    'priority': issue.get('severity', 'medium'),
                    'title': issue['title'],
                    'description': issue['description'],
                    'action_items': issue.get('action_items', [])
                })
        
        # Linking recommendations
        for opportunity in linking_opportunities['orphan_pages']:
            recommendations.append({
                'category': 'Internal Linking',
                'priority': 'medium',
                'title': f"Strengthen internal links to: {opportunity['title']}",
                'description': f"Page '{opportunity['title']}' appears to be an orphan page with limited internal links.",
                'action_items': [
                    f"Add internal links from related pages to {opportunity['url']}",
                    "Consider creating a hub page that links to this content",
                    "Add contextual links within existing content"
                ]
            })
        
        return AnalysisResult(
            mode=AnalysisMode.MY_SITE.value,
            domain=site_data.domain,
            timestamp=datetime.now(timezone.utc).isoformat(),
            summary={
                'total_pages_analyzed': site_data.total_pages,
                'seo_score': seo_audit['score'],
                'technical_issues_found': len(seo_audit['issues']),
                'orphan_pages_identified': len(linking_opportunities['orphan_pages']),
                'site_category': site_blueprint['category'],
                'content_archetypes': len(site_blueprint['content_archetypes'])
            },
            recommendations=recommendations,
            metadata={
                'analysis_type': 'comprehensive_audit',
                'crawl_depth': site_data.analysis_metadata,
                'blueprint_generated': True,
                'seo_audit_completed': True,
                'linking_analysis_completed': True
            },
            raw_data={
                'seo_audit': seo_audit,
                'site_blueprint': site_blueprint,
                'linking_opportunities': linking_opportunities
            }
        )
    
    def _analyze_competitor(self, site_data: SiteData) -> AnalysisResult:
        """
        Analyze competitor site for strategy intelligence and opportunities.
        
        Args:
            site_data: Crawled site data
            
        Returns:
            AnalysisResult with competitor analysis
        """
        
        logger.info(f"Performing competitor analysis for {site_data.domain}")
        
        # Content strategy analysis
        content_strategy = self._analyze_content_strategy(site_data)
        
        # SEO keyword strategy
        keyword_strategy = self._analyze_keyword_strategy(site_data)
        
        # Strategic opportunities and gaps
        opportunities = self._identify_strategic_opportunities(site_data, content_strategy, keyword_strategy)
        
        # Compile recommendations
        recommendations = []
        
        for opportunity in opportunities:
            recommendations.append({
                'category': 'Competitive Opportunity',
                'priority': opportunity.get('priority', 'medium'),
                'title': opportunity['title'],
                'description': opportunity['description'],
                'action_items': opportunity.get('action_items', []),
                'competitive_advantage': opportunity.get('advantage', '')
            })
        
        return AnalysisResult(
            mode=AnalysisMode.COMPETITOR.value,
            domain=site_data.domain,
            timestamp=datetime.now(timezone.utc).isoformat(),
            summary={
                'total_pages_analyzed': site_data.total_pages,
                'primary_content_formats': content_strategy['primary_formats'],
                'topical_clusters_identified': len(content_strategy['topical_clusters']),
                'target_keywords_identified': len(keyword_strategy['target_keywords']),
                'strategic_opportunities': len(opportunities),
                'competitor_tone': content_strategy['tone_of_voice'],
                'content_gaps_found': len([opp for opp in opportunities if 'gap' in opp.get('type', '')])
            },
            recommendations=recommendations,
            metadata={
                'analysis_type': 'competitive_intelligence',
                'strategy_analysis_completed': True,
                'keyword_analysis_completed': True,
                'opportunity_analysis_completed': True
            },
            raw_data={
                'content_strategy': content_strategy,
                'keyword_strategy': keyword_strategy,
                'strategic_opportunities': opportunities
            }
        )
    
    def _analyze_prospect(self, site_data: SiteData) -> AnalysisResult:
        """
        Analyze prospect site for sales and lead generation report.
        
        Args:
            site_data: Crawled site data
            
        Returns:
            AnalysisResult with prospect analysis
        """
        
        logger.info(f"Performing prospect analysis for {site_data.domain}")
        
        # Missed opportunities audit
        missed_opportunities = self._audit_missed_opportunities(site_data)
        
        # Generate mini-proposal
        mini_proposal = self._generate_mini_proposal(site_data, missed_opportunities)
        
        # Compile recommendations (formatted for client presentation)
        recommendations = []
        
        for opportunity in missed_opportunities:
            recommendations.append({
                'category': 'Growth Opportunity',
                'priority': 'high',
                'title': opportunity['title'],
                'description': opportunity['description'],
                'business_impact': opportunity['business_impact'],
                'solution': opportunity['solution'],
                'estimated_effort': opportunity.get('effort', 'medium')
            })
        
        return AnalysisResult(
            mode=AnalysisMode.PROSPECT.value,
            domain=site_data.domain,
            timestamp=datetime.now(timezone.utc).isoformat(),
            summary={
                'total_pages_analyzed': site_data.total_pages,
                'opportunities_identified': len(missed_opportunities),
                'high_impact_opportunities': len([opp for opp in missed_opportunities if opp.get('impact_level') == 'high']),
                'proposal_generated': True,
                'audit_score': mini_proposal.get('audit_score', 'N/A')
            },
            recommendations=recommendations,
            metadata={
                'analysis_type': 'prospect_audit',
                'proposal_ready': True,
                'email_friendly_format': True,
                'client_presentation_ready': True
            },
            raw_data={
                'missed_opportunities_audit': missed_opportunities,
                'mini_proposal': mini_proposal,
                'email_template': mini_proposal.get('email_template', '')
            }
        )
    
    def _perform_technical_seo_audit(self, site_data: SiteData) -> Dict[str, Any]:
        """Perform technical SEO audit on site data."""
        
        issues = []
        titles = [page.title for page in site_data.pages]
        meta_descriptions = [page.meta_description for page in site_data.pages]
        h1_tags = [h1 for page in site_data.pages for h1 in page.h1_tags]
        
        # Check for duplicate titles
        title_counts = {}
        for title in titles:
            if title:
                title_counts[title] = title_counts.get(title, 0) + 1
        
        duplicates = [title for title, count in title_counts.items() if count > 1]
        if duplicates:
            issues.append({
                'title': 'Duplicate Title Tags',
                'description': f"Found {len(duplicates)} duplicate title tags",
                'severity': 'high',
                'action_items': [
                    'Review and rewrite duplicate title tags',
                    'Ensure each page has a unique, descriptive title',
                    'Follow title tag best practices (50-60 characters)'
                ]
            })
        
        # Check for missing meta descriptions
        missing_meta = len([desc for desc in meta_descriptions if not desc])
        if missing_meta > 0:
            issues.append({
                'title': 'Missing Meta Descriptions',
                'description': f"{missing_meta} pages are missing meta descriptions",
                'severity': 'medium',
                'action_items': [
                    'Add unique meta descriptions to all pages',
                    'Keep descriptions between 150-160 characters',
                    'Include target keywords naturally'
                ]
            })
        
        # Check title lengths
        long_titles = len([title for title in titles if len(title) > 60])
        short_titles = len([title for title in titles if len(title) < 30 and title])
        
        if long_titles > 0 or short_titles > 0:
            issues.append({
                'title': 'Title Length Issues',
                'description': f"{long_titles} titles too long, {short_titles} titles too short",
                'severity': 'medium',
                'action_items': [
                    'Optimize title lengths (30-60 characters)',
                    'Ensure titles are descriptive but concise',
                    'Place important keywords at the beginning'
                ]
            })
        
        # Analyze H1 keywords
        h1_keywords = {}
        for h1 in h1_tags:
            if h1:
                words = re.findall(r'\b\w+\b', h1.lower())
                for word in words:
                    if len(word) > 3:  # Skip short words
                        h1_keywords[word] = h1_keywords.get(word, 0) + 1
        
        top_keywords = sorted(h1_keywords.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # Calculate SEO score
        total_pages = len(site_data.pages)
        issue_count = len(issues)
        seo_score = max(0, 100 - (issue_count * 15))  # Simple scoring
        
        return {
            'score': seo_score,
            'issues': issues,
            'top_h1_keywords': top_keywords,
            'statistics': {
                'total_pages': total_pages,
                'pages_with_titles': len([t for t in titles if t]),
                'pages_with_meta_descriptions': len([d for d in meta_descriptions if d]),
                'unique_titles': len(set(titles)),
                'average_title_length': sum(len(t) for t in titles if t) / len([t for t in titles if t]) if titles else 0
            }
        }
    
    def _generate_site_blueprint(self, site_data: SiteData) -> Dict[str, Any]:
        """Generate a site strategy blueprint."""
        
        # Analyze content patterns
        page_titles = [page.title for page in site_data.pages if page.title]
        h1_tags = [h1 for page in site_data.pages for h1 in page.h1_tags]
        
        # Identify content archetypes
        content_archetypes = []
        
        # Look for common patterns
        if any('guide' in title.lower() or 'how to' in title.lower() for title in page_titles):
            content_archetypes.append('How-to Guides')
        
        if any('review' in title.lower() or 'best' in title.lower() for title in page_titles):
            content_archetypes.append('Reviews & Comparisons')
        
        if any('tips' in title.lower() or 'ways to' in title.lower() for title in page_titles):
            content_archetypes.append('Tips & Lists')
        
        if any('news' in title.lower() or 'update' in title.lower() for title in page_titles):
            content_archetypes.append('News & Updates')
        
        # Determine site category (simplified)
        all_text = ' '.join(page_titles + h1_tags).lower()
        
        category = 'General'
        if any(word in all_text for word in ['business', 'marketing', 'finance', 'startup']):
            category = 'Business & Finance'
        elif any(word in all_text for word in ['health', 'fitness', 'wellness', 'medical']):
            category = 'Health & Wellness'
        elif any(word in all_text for word in ['tech', 'software', 'digital', 'app']):
            category = 'Technology'
        elif any(word in all_text for word in ['travel', 'destination', 'trip', 'vacation']):
            category = 'Travel'
        
        return {
            'category': category,
            'content_archetypes': content_archetypes,
            'persona': 'Professional',  # Simplified
            'target_audience': 'General consumers',  # Simplified
            'tone_of_voice': 'Informative',  # Simplified
            'strategy_recommendations': [
                'Focus on comprehensive guides',
                'Build topical authority in core areas',
                'Improve internal linking structure'
            ]
        }
    
    def _analyze_internal_linking(self, site_data: SiteData) -> Dict[str, Any]:
        """Analyze internal linking opportunities."""
        
        # Count internal links to each page
        link_counts = {}
        all_internal_links = []
        
        for page in site_data.pages:
            all_internal_links.extend(page.internal_links)
        
        for link in all_internal_links:
            link_counts[link] = link_counts.get(link, 0) + 1
        
        # Identify potential orphan pages (pages with very few internal links)
        orphan_pages = []
        
        for page in site_data.pages:
            link_count = link_counts.get(page.url, 0)
            if link_count <= 1 and len(site_data.pages) > 5:  # Only if site has multiple pages
                orphan_pages.append({
                    'url': page.url,
                    'title': page.title,
                    'internal_link_count': link_count,
                    'word_count': page.word_count
                })
        
        # Sort by word count (longer content might be more valuable)
        orphan_pages.sort(key=lambda x: x['word_count'], reverse=True)
        
        return {
            'orphan_pages': orphan_pages[:3],  # Top 3 orphan pages
            'total_internal_links': len(all_internal_links),
            'pages_analyzed': len(site_data.pages),
            'linking_recommendations': [
                'Create hub pages that link to related content',
                'Add contextual internal links within content',
                'Build topic clusters with strong internal linking'
            ]
        }
    
    def _analyze_content_strategy(self, site_data: SiteData) -> Dict[str, Any]:
        """Analyze competitor's content strategy."""
        
        page_titles = [page.title for page in site_data.pages if page.title]
        h1_tags = [h1 for page in site_data.pages for h1 in page.h1_tags]
        
        # Identify content formats
        formats = []
        if any('how to' in title.lower() for title in page_titles):
            formats.append('How-to Guides')
        if any('review' in title.lower() for title in page_titles):
            formats.append('Reviews')
        if any('best' in title.lower() or 'top' in title.lower() for title in page_titles):
            formats.append('Listicles')
        if any('guide' in title.lower() for title in page_titles):
            formats.append('Comprehensive Guides')
        
        # Identify topical clusters (simplified)
        all_text = ' '.join(page_titles + h1_tags).lower()
        clusters = []
        
        common_topics = ['business', 'marketing', 'health', 'technology', 'travel', 'finance']
        for topic in common_topics:
            if topic in all_text:
                clusters.append(topic.title())
        
        return {
            'primary_formats': formats[:3],  # Top 3 formats
            'topical_clusters': clusters,
            'tone_of_voice': 'Professional',  # Simplified analysis
            'content_volume': len(site_data.pages),
            'average_content_length': sum(page.word_count for page in site_data.pages) / len(site_data.pages) if site_data.pages else 0
        }
    
    def _analyze_keyword_strategy(self, site_data: SiteData) -> Dict[str, Any]:
        """Analyze competitor's keyword strategy."""
        
        # Extract keywords from titles and H1s
        all_text = []
        for page in site_data.pages:
            if page.title:
                all_text.append(page.title.lower())
            all_text.extend([h1.lower() for h1 in page.h1_tags])
        
        # Simple keyword extraction
        words = []
        for text in all_text:
            words.extend(re.findall(r'\b\w+\b', text))
        
        # Count word frequency (excluding common words)
        common_words = {'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should'}
        
        word_counts = {}
        for word in words:
            if len(word) > 3 and word not in common_words:
                word_counts[word] = word_counts.get(word, 0) + 1
        
        target_keywords = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        
        return {
            'target_keywords': target_keywords,
            'keyword_density_patterns': 'moderate',  # Simplified
            'long_tail_usage': 'present' if any(len(title.split()) > 5 for title in [page.title for page in site_data.pages if page.title]) else 'limited'
        }
    
    def _identify_strategic_opportunities(self, site_data: SiteData, content_strategy: Dict, keyword_strategy: Dict) -> List[Dict[str, Any]]:
        """Identify strategic opportunities based on competitor analysis."""
        
        opportunities = []
        
        # Content gap opportunities
        if len(content_strategy['topical_clusters']) < 3:
            opportunities.append({
                'title': 'Limited Topical Authority',
                'description': 'Competitor has narrow topical focus, creating opportunities for broader content coverage.',
                'type': 'content_gap',
                'priority': 'high',
                'advantage': 'Build comprehensive content hubs in adjacent topics',
                'action_items': [
                    'Identify related topics they don\'t cover',
                    'Create comprehensive guides in these areas',
                    'Build topical authority through consistent publishing'
                ]
            })
        
        # Content format opportunities
        missing_formats = []
        all_formats = ['How-to Guides', 'Reviews', 'Listicles', 'Case Studies', 'Tools & Resources']
        for format in all_formats:
            if format not in content_strategy['primary_formats']:
                missing_formats.append(format)
        
        if missing_formats:
            opportunities.append({
                'title': 'Content Format Gaps',
                'description': f'Competitor is not utilizing these content formats: {", ".join(missing_formats[:2])}',
                'type': 'format_gap',
                'priority': 'medium',
                'advantage': 'Diversify content portfolio with underused formats',
                'action_items': [
                    f'Create {missing_formats[0].lower()} content',
                    'Test different content formats for engagement',
                    'Build format-specific content series'
                ]
            })
        
        # Content depth opportunity
        avg_length = content_strategy.get('average_content_length', 0)
        if avg_length < 800:
            opportunities.append({
                'title': 'Content Depth Advantage',
                'description': 'Competitor\'s content appears to be relatively shallow. Opportunity for more comprehensive coverage.',
                'type': 'depth_gap',
                'priority': 'high',
                'advantage': 'Create more comprehensive, authoritative content',
                'action_items': [
                    'Create long-form, comprehensive guides',
                    'Add more examples and case studies',
                    'Include expert insights and data'
                ]
            })
        
        return opportunities
    
    def _audit_missed_opportunities(self, site_data: SiteData) -> List[Dict[str, Any]]:
        """Audit missed opportunities for prospect report."""
        
        opportunities = []
        
        # Technical SEO audit (simplified for prospect)
        seo_audit = self._perform_technical_seo_audit(site_data)
        
        if seo_audit['score'] < 80:
            opportunities.append({
                'title': 'Technical SEO Issues',
                'description': f'Your website has several technical SEO issues that could be limiting organic search visibility.',
                'business_impact': 'Reduced organic traffic and search engine rankings',
                'solution': 'Implement comprehensive technical SEO audit and fixes',
                'impact_level': 'high',
                'effort': 'medium'
            })
        
        # Content opportunities
        if site_data.total_pages < 20:
            opportunities.append({
                'title': 'Limited Content Volume',
                'description': 'Your website has relatively few pages, which may limit your ability to capture organic search traffic.',
                'business_impact': 'Missing out on long-tail keyword opportunities and organic traffic',
                'solution': 'Develop a content strategy with regular, high-quality content publishing',
                'impact_level': 'high',
                'effort': 'high'
            })
        
        # Internal linking
        linking_analysis = self._analyze_internal_linking(site_data)
        if len(linking_analysis['orphan_pages']) > 0:
            opportunities.append({
                'title': 'Weak Internal Link Structure',
                'description': 'Several pages on your website appear to have limited internal links, reducing their SEO potential.',
                'business_impact': 'Poor page authority distribution and reduced user engagement',
                'solution': 'Implement strategic internal linking to improve page authority and user navigation',
                'impact_level': 'medium',
                'effort': 'low'
            })
        
        # Mobile and performance (placeholder)
        opportunities.append({
            'title': 'Page Performance Optimization',
            'description': 'Website performance optimization could improve user experience and search rankings.',
            'business_impact': 'Higher bounce rates and lower conversion rates',
            'solution': 'Implement performance optimization including image compression, caching, and code minification',
            'impact_level': 'medium',
            'effort': 'medium'
        })
        
        # Content quality
        avg_word_count = sum(page.word_count for page in site_data.pages) / len(site_data.pages) if site_data.pages else 0
        if avg_word_count < 500:
            opportunities.append({
                'title': 'Content Depth and Quality',
                'description': 'Your content could benefit from more comprehensive coverage of topics to establish authority.',
                'business_impact': 'Reduced user engagement and lower search engine rankings',
                'solution': 'Create more comprehensive, in-depth content that thoroughly covers topics',
                'impact_level': 'high',
                'effort': 'high'
            })
        
        return opportunities[:5]  # Return top 5 opportunities
    
    def _generate_mini_proposal(self, site_data: SiteData, opportunities: List[Dict]) -> Dict[str, Any]:
        """Generate a mini-proposal for prospects."""
        
        # Calculate audit score
        total_score = 100
        for opportunity in opportunities:
            if opportunity['impact_level'] == 'high':
                total_score -= 25
            elif opportunity['impact_level'] == 'medium':
                total_score -= 15
            else:
                total_score -= 5
        
        audit_score = max(0, total_score)
        
        # Create email template
        email_template = self._create_email_template(site_data, opportunities, audit_score)
        
        return {
            'audit_score': f"{audit_score}/100",
            'total_opportunities': len(opportunities),
            'high_impact_opportunities': len([opp for opp in opportunities if opp['impact_level'] == 'high']),
            'email_template': email_template,
            'proposal_summary': {
                'strengths': ['Professional website design', 'Clear navigation structure'],
                'key_opportunities': [opp['title'] for opp in opportunities[:3]],
                'potential_impact': 'Significant improvement in organic search visibility and user engagement'
            }
        }
    
    def _create_email_template(self, site_data: SiteData, opportunities: List[Dict], audit_score: int) -> str:
        """Create an email-friendly proposal template."""
        
        domain = site_data.domain
        
        template = f"""Subject: Quick SEO Analysis Results for {domain}

Hi there,

I hope this email finds you well. I recently took a look at {domain} and wanted to share some quick insights that could help improve your online presence.

First off, I'm impressed with your professional website design and clear navigation structure. You've clearly put thought into the user experience.

During my analysis, I identified several opportunities that could significantly boost your organic search visibility and user engagement:

"""
        
        for i, opportunity in enumerate(opportunities[:3], 1):
            template += f"{i}. **{opportunity['title']}**: {opportunity['description']} This could be impacting your {opportunity['business_impact'].lower()}.\n\n"
        
        template += f"""Based on this analysis, your current SEO foundation scores {audit_score}/100, which indicates there's substantial room for improvement.

The good news is that these are all very addressable opportunities. With the right strategy, we could potentially help you:
- Increase organic search traffic
- Improve search engine rankings  
- Enhance user engagement and conversion rates
- Build stronger topical authority in your industry

I'd love to discuss how we could help you capitalize on these opportunities. Would you be interested in a brief 15-minute call to explore how a comprehensive SEO and content strategy could benefit {domain}?

Best regards,
[Your Name]

P.S. This analysis just scratches the surface. A comprehensive audit would reveal additional opportunities for growth and optimization.
"""
        
        return template
    
    def _create_error_result(self, url: str, mode: AnalysisMode, error_message: str) -> AnalysisResult:
        """Create an error result when analysis fails."""
        
        parsed_url = urlparse(url)
        domain = parsed_url.netloc if parsed_url.netloc else url
        
        return AnalysisResult(
            mode=mode.value,
            domain=domain,
            timestamp=datetime.now(timezone.utc).isoformat(),
            summary={
                'error': True,
                'error_message': error_message,
                'analysis_completed': False
            },
            recommendations=[],
            metadata={
                'analysis_type': 'failed',
                'error_occurred': True,
                'url_attempted': url
            }
        )


