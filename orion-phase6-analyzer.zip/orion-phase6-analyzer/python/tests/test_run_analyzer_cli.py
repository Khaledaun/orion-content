
"""
Tests for CLI interface - Phase 6 Orion Content Analyzer.
"""

import pytest
import json
import tempfile
from unittest.mock import Mock, patch, MagicMock
from pathlib import Path

from orion.analyze.run_analyzer import (
    parse_arguments, validate_url, get_domain_from_url, 
    save_analysis_result, print_summary, main
)
from orion.analyze.analyzer import AnalysisResult, AnalysisMode


class TestCLIArgumentParsing:
    """Test CLI argument parsing functionality."""
    
    def test_parse_basic_arguments(self):
        """Test parsing of basic required arguments."""
        
        with patch('sys.argv', ['run_analyzer.py', '--url', 'https://example.com', '--mode', 'my-site']):
            args = parse_arguments()
        
        assert args.url == 'https://example.com'
        assert args.mode == 'my-site'
        assert args.output == './analysis-reports/'  # Default value
        assert args.max_pages == 50  # Default value
        assert args.use_llm is False  # Default value
        assert args.verbose is False  # Default value
        assert args.format == 'json'  # Default value
    
    def test_parse_all_arguments(self):
        """Test parsing with all arguments provided."""
        
        test_args = [
            'run_analyzer.py',
            '--url', 'https://test.com',
            '--mode', 'competitor',
            '--output', './custom-reports/',
            '--max-pages', '25',
            '--use-llm',
            '--verbose',
            '--format', 'summary'
        ]
        
        with patch('sys.argv', test_args):
            args = parse_arguments()
        
        assert args.url == 'https://test.com'
        assert args.mode == 'competitor'
        assert args.output == './custom-reports/'
        assert args.max_pages == 25
        assert args.use_llm is True
        assert args.verbose is True
        assert args.format == 'summary'
    
    def test_parse_mode_choices(self):
        """Test that mode argument accepts valid choices."""
        
        valid_modes = ['my-site', 'competitor', 'prospect']
        
        for mode in valid_modes:
            with patch('sys.argv', ['run_analyzer.py', '--url', 'https://example.com', '--mode', mode]):
                args = parse_arguments()
                assert args.mode == mode
    
    def test_parse_format_choices(self):
        """Test that format argument accepts valid choices."""
        
        valid_formats = ['json', 'summary']
        
        for format_type in valid_formats:
            with patch('sys.argv', [
                'run_analyzer.py', '--url', 'https://example.com', 
                '--mode', 'my-site', '--format', format_type
            ]):
                args = parse_arguments()
                assert args.format == format_type


class TestURLValidation:
    """Test URL validation functionality."""
    
    def test_valid_urls(self):
        """Test validation of valid URLs."""
        
        valid_urls = [
            'https://example.com',
            'http://example.com',
            'https://www.example.com',
            'https://subdomain.example.com',
            'https://example.com/path',
            'https://example.co.uk',
            'http://localhost:8080'
        ]
        
        for url in valid_urls:
            assert validate_url(url) is True, f"Should accept valid URL: {url}"
    
    def test_invalid_urls(self):
        """Test validation of invalid URLs."""
        
        invalid_urls = [
            'not-a-url',
            'example.com',  # Missing protocol
            'ftp://example.com',  # Invalid protocol
            '',  # Empty string
            'https://',  # Missing domain
            'https://.'  # Invalid domain
        ]
        
        for url in invalid_urls:
            assert validate_url(url) is False, f"Should reject invalid URL: {url}"
    
    def test_get_domain_from_url(self):
        """Test domain extraction from URLs."""
        
        test_cases = [
            ('https://example.com', 'example_com'),
            ('https://www.example.com', 'example_com'),
            ('https://subdomain.example.com/path', 'subdomain_example_com'),
            ('http://localhost:8080', 'localhost_8080'),
            ('https://example.co.uk/path?query=1', 'example_co_uk')
        ]
        
        for url, expected in test_cases:
            result = get_domain_from_url(url)
            assert result == expected, f"URL {url} should produce domain {expected}, got {result}"


class TestResultSaving:
    """Test analysis result saving functionality."""
    
    @pytest.fixture
    def sample_analysis_result(self):
        """Create a sample analysis result for testing."""
        
        return AnalysisResult(
            mode="my-site",
            domain="example.com",
            timestamp="2024-08-28T12:00:00Z",
            summary={
                "total_pages_analyzed": 5,
                "seo_score": 75,
                "technical_issues_found": 2
            },
            recommendations=[
                {
                    "category": "Technical SEO",
                    "priority": "high",
                    "title": "Fix Missing Meta Descriptions",
                    "description": "Add meta descriptions to improve search visibility"
                }
            ],
            metadata={
                "analysis_type": "comprehensive_audit",
                "crawl_depth": {"max_pages": 50}
            },
            raw_data={
                "seo_audit": {"score": 75, "issues": []},
                "site_blueprint": {"category": "Business"}
            }
        )
    
    def test_save_json_format(self, sample_analysis_result):
        """Test saving results in JSON format."""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            output_file = save_analysis_result(sample_analysis_result, temp_dir, 'json')
            
            # Check file was created
            assert output_file.endswith('.json')
            assert Path(output_file).exists()
            
            # Check file content
            with open(output_file, 'r') as f:
                data = json.load(f)
            
            assert data['mode'] == 'my-site'
            assert data['domain'] == 'example.com'
            assert data['summary']['seo_score'] == 75
            assert len(data['recommendations']) == 1
    
    def test_save_summary_format(self, sample_analysis_result):
        """Test saving results in summary format."""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            output_file = save_analysis_result(sample_analysis_result, temp_dir, 'summary')
            
            # Check file was created
            assert output_file.endswith('.txt')
            assert Path(output_file).exists()
            
            # Check file content
            with open(output_file, 'r') as f:
                content = f.read()
            
            assert 'Orion Content Analysis Report' in content
            assert 'example.com' in content
            assert 'my-site' in content
            assert 'Fix Missing Meta Descriptions' in content
    
    def test_filename_generation(self, sample_analysis_result):
        """Test that filenames are generated correctly."""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            output_file = save_analysis_result(sample_analysis_result, temp_dir, 'json')
            
            filename = Path(output_file).name
            expected = 'analysis-report-my-site-example_com.json'
            assert filename == expected


class TestCLIMain:
    """Test main CLI functionality."""
    
    @patch('orion.analyze.run_analyzer.SiteAnalyzer')
    def test_successful_analysis(self, mock_analyzer_class):
        """Test successful analysis execution."""
        
        # Mock analyzer instance
        mock_analyzer = Mock()
        mock_analyzer_class.return_value = mock_analyzer
        
        # Mock analysis result
        mock_result = AnalysisResult(
            mode="my-site",
            domain="example.com",
            timestamp="2024-08-28T12:00:00Z",
            summary={
                "error": False,
                "total_pages_analyzed": 5,
                "seo_score": 80
            },
            recommendations=[],
            metadata={},
            raw_data={}
        )
        mock_analyzer.analyze_site.return_value = mock_result
        
        test_args = [
            'run_analyzer.py',
            '--url', 'https://example.com',
            '--mode', 'my-site'
        ]
        
        with patch('sys.argv', test_args), \
             patch('orion.analyze.run_analyzer.save_analysis_result') as mock_save, \
             patch('orion.analyze.run_analyzer.print_summary') as mock_print, \
             tempfile.TemporaryDirectory() as temp_dir:
            
            mock_save.return_value = f"{temp_dir}/report.json"
            
            result = main()
            
            # Check successful execution
            assert result == 0
            
            # Check analyzer was called correctly
            mock_analyzer.analyze_site.assert_called_once()
            args, kwargs = mock_analyzer.analyze_site.call_args
            assert args[0] == 'https://example.com'
            assert args[1] == AnalysisMode.MY_SITE
            
            # Check result was saved and printed
            mock_save.assert_called_once()
            mock_print.assert_called_once_with(mock_result)
    
    @patch('orion.analyze.run_analyzer.SiteAnalyzer')
    def test_analysis_error_handling(self, mock_analyzer_class):
        """Test handling of analysis errors."""
        
        # Mock analyzer instance
        mock_analyzer = Mock()
        mock_analyzer_class.return_value = mock_analyzer
        
        # Mock error result
        mock_result = AnalysisResult(
            mode="my-site",
            domain="example.com",
            timestamp="2024-08-28T12:00:00Z",
            summary={
                "error": True,
                "error_message": "Failed to crawl site"
            },
            recommendations=[],
            metadata={},
            raw_data={}
        )
        mock_analyzer.analyze_site.return_value = mock_result
        
        test_args = [
            'run_analyzer.py',
            '--url', 'https://example.com',
            '--mode', 'my-site'
        ]
        
        with patch('sys.argv', test_args):
            result = main()
            
            # Should return error code
            assert result == 1
    
    def test_invalid_url_handling(self):
        """Test handling of invalid URLs."""
        
        test_args = [
            'run_analyzer.py',
            '--url', 'invalid-url',
            '--mode', 'my-site'
        ]
        
        with patch('sys.argv', test_args):
            result = main()
            
            # Should return error code for invalid URL
            assert result == 1
    
    @patch('orion.analyze.run_analyzer.SiteAnalyzer')
    def test_keyboard_interrupt_handling(self, mock_analyzer_class):
        """Test handling of keyboard interrupts."""
        
        # Mock analyzer to raise KeyboardInterrupt
        mock_analyzer = Mock()
        mock_analyzer_class.return_value = mock_analyzer
        mock_analyzer.analyze_site.side_effect = KeyboardInterrupt()
        
        test_args = [
            'run_analyzer.py',
            '--url', 'https://example.com',
            '--mode', 'my-site'
        ]
        
        with patch('sys.argv', test_args):
            result = main()
            
            # Should return specific code for keyboard interrupt
            assert result == 130
    
    @patch('orion.analyze.run_analyzer.SiteAnalyzer')
    def test_prospect_mode_email_output(self, mock_analyzer_class):
        """Test that prospect mode outputs email template."""
        
        # Mock analyzer instance
        mock_analyzer = Mock()
        mock_analyzer_class.return_value = mock_analyzer
        
        # Mock prospect result with email template
        mock_result = AnalysisResult(
            mode="prospect",
            domain="prospect.com",
            timestamp="2024-08-28T12:00:00Z",
            summary={
                "error": False,
                "total_pages_analyzed": 3,
                "proposal_generated": True
            },
            recommendations=[],
            metadata={},
            raw_data={
                'mini_proposal': {
                    'email_template': 'Subject: Test Email\n\nHi there,\n\nTest email content.'
                }
            }
        )
        mock_analyzer.analyze_site.return_value = mock_result
        
        test_args = [
            'run_analyzer.py',
            '--url', 'https://prospect.com',
            '--mode', 'prospect'
        ]
        
        with patch('sys.argv', test_args), \
             patch('orion.analyze.run_analyzer.save_analysis_result'), \
             patch('builtins.print') as mock_print:
            
            result = main()
            
            # Check successful execution
            assert result == 0
            
            # Check that email template was printed
            print_calls = [str(call) for call in mock_print.call_args_list]
            email_printed = any('EMAIL TEMPLATE' in call for call in print_calls)
            assert email_printed


class TestPrintSummary:
    """Test summary printing functionality."""
    
    def test_print_basic_summary(self):
        """Test printing of basic summary."""
        
        result = AnalysisResult(
            mode="my-site",
            domain="example.com",
            timestamp="2024-08-28T12:00:00Z",
            summary={
                "total_pages_analyzed": 5,
                "seo_score": 75,
                "technical_issues_found": 2
            },
            recommendations=[
                {
                    "priority": "high",
                    "title": "Fix Technical SEO Issues"
                },
                {
                    "priority": "medium",
                    "title": "Improve Content Length"
                }
            ],
            metadata={},
            raw_data={}
        )
        
        with patch('builtins.print') as mock_print:
            print_summary(result)
            
            # Check that key information was printed
            print_calls = [str(call) for call in mock_print.call_args_list]
            content = ' '.join(print_calls)
            
            assert 'example.com' in content
            assert 'MY-SITE' in content
            assert 'Total Pages Analyzed: 5' in content
            assert 'Fix Technical SEO Issues' in content
    
    def test_print_prospect_summary(self):
        """Test printing of prospect-specific summary."""
        
        result = AnalysisResult(
            mode="prospect",
            domain="prospect.com",
            timestamp="2024-08-28T12:00:00Z",
            summary={
                "total_pages_analyzed": 3,
                "opportunities_identified": 5,
                "proposal_generated": True
            },
            recommendations=[],
            metadata={},
            raw_data={
                'mini_proposal': {
                    'audit_score': '65/100'
                }
            }
        )
        
        with patch('builtins.print') as mock_print:
            print_summary(result)
            
            # Check prospect-specific content
            print_calls = [str(call) for call in mock_print.call_args_list]
            content = ' '.join(print_calls)
            
            assert 'PROSPECT REPORT' in content
            assert '65/100' in content
    
    def test_print_competitor_summary(self):
        """Test printing of competitor-specific summary."""
        
        result = AnalysisResult(
            mode="competitor",
            domain="competitor.com",
            timestamp="2024-08-28T12:00:00Z",
            summary={
                "total_pages_analyzed": 10,
                "strategic_opportunities": 3
            },
            recommendations=[],
            metadata={},
            raw_data={
                'content_strategy': {
                    'primary_formats': ['How-to Guides', 'Reviews'],
                    'topical_clusters': ['Marketing', 'Business']
                }
            }
        )
        
        with patch('builtins.print') as mock_print:
            print_summary(result)
            
            # Check competitor-specific content
            print_calls = [str(call) for call in mock_print.call_args_list]
            content = ' '.join(print_calls)
            
            assert 'COMPETITOR INSIGHTS' in content
            assert 'How-to Guides' in content
            assert 'Marketing' in content


