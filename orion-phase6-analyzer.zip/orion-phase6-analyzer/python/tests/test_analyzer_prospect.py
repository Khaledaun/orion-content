
"""
Tests for prospect analysis mode - Phase 6 Orion Content Analyzer.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
import json
from datetime import datetime

from orion.analyze.analyzer import SiteAnalyzer, AnalysisMode, SiteData, PageData, AnalysisResult


class TestProspectAnalyzer:
    """Test suite for prospect analysis mode."""
    
    @pytest.fixture
    def prospect_site_data(self):
        """Create sample prospect site data for testing."""
        pages = [
            PageData(
                url="https://prospect.com/",
                title="Welcome to Our Business - Super Long Title That Exceeds the Recommended Length for SEO",
                meta_description="",  # Missing meta description
                h1_tags=["Welcome to Business"],
                h2_tags=["Our Services", "Contact"],
                word_count=250,  # Short content
                internal_links=[],  # No internal links
                external_links=["https://google.com"]
            ),
            PageData(
                url="https://prospect.com/services",
                title="Services",  # Too short title
                meta_description="We provide services",  # Short meta description
                h1_tags=["Our Services"],
                h2_tags=[],
                word_count=150,  # Very short content
                internal_links=["https://prospect.com/"],
                external_links=[]
            ),
            PageData(
                url="https://prospect.com/about",
                title="About Us - Learn More",
                meta_description="",  # Missing meta description
                h1_tags=["About Our Company"],
                h2_tags=["History", "Team"],
                word_count=300,
                internal_links=["https://prospect.com/"],
                external_links=[]
            )
        ]
        
        return SiteData(
            domain="prospect.com",
            base_url="https://prospect.com",
            total_pages=3,
            pages=pages,
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={'max_pages_limit': 50, 'actual_pages_crawled': 3}
        )
    
    def test_prospect_analysis_basic(self, prospect_site_data):
        """Test basic prospect analysis functionality."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=prospect_site_data):
            result = analyzer.analyze_site("https://prospect.com", AnalysisMode.PROSPECT)
        
        # Check basic result structure
        assert result.mode == "prospect"
        assert result.domain == "prospect.com"
        assert isinstance(result.summary, dict)
        assert isinstance(result.recommendations, list)
        assert isinstance(result.metadata, dict)
        
        # Check prospect-specific summary content
        assert result.summary['total_pages_analyzed'] == 3
        assert 'opportunities_identified' in result.summary
        assert 'high_impact_opportunities' in result.summary
        assert 'proposal_generated' in result.summary
        assert 'audit_score' in result.summary
        
        # Proposal should be generated
        assert result.summary['proposal_generated'] is True
    
    def test_missed_opportunities_audit(self, prospect_site_data):
        """Test missed opportunities audit functionality."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        opportunities = analyzer._audit_missed_opportunities(prospect_site_data)
        
        # Check structure
        assert isinstance(opportunities, list)
        assert len(opportunities) > 0
        assert len(opportunities) <= 5  # Should limit to top 5
        
        # Check opportunity structure
        for opp in opportunities:
            assert 'title' in opp
            assert 'description' in opp
            assert 'business_impact' in opp
            assert 'solution' in opp
            assert 'impact_level' in opp
            assert 'effort' in opp
            
            # Check valid values
            assert opp['impact_level'] in ['low', 'medium', 'high']
            assert opp['effort'] in ['low', 'medium', 'high']
        
        # Should identify technical SEO issues due to poor sample data
        opportunity_titles = [opp['title'] for opp in opportunities]
        assert any('SEO' in title for title in opportunity_titles)
        
        # Should identify limited content volume (only 3 pages)
        assert any('Content' in title for title in opportunity_titles)
    
    def test_mini_proposal_generation(self, prospect_site_data):
        """Test mini-proposal generation functionality."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        # First get opportunities
        opportunities = analyzer._audit_missed_opportunities(prospect_site_data)
        
        # Generate mini-proposal
        proposal = analyzer._generate_mini_proposal(prospect_site_data, opportunities)
        
        # Check structure
        assert 'audit_score' in proposal
        assert 'total_opportunities' in proposal
        assert 'high_impact_opportunities' in proposal
        assert 'email_template' in proposal
        assert 'proposal_summary' in proposal
        
        # Check audit score format
        audit_score = proposal['audit_score']
        assert '/' in audit_score  # Should be in format "XX/100"
        assert audit_score.endswith('/100')
        
        # Check email template
        email_template = proposal['email_template']
        assert len(email_template) > 0
        assert 'prospect.com' in email_template  # Should mention the domain
        assert 'Subject:' in email_template  # Should include email subject
        
        # Check proposal summary
        summary = proposal['proposal_summary']
        assert 'strengths' in summary
        assert 'key_opportunities' in summary
        assert 'potential_impact' in summary
        
        assert isinstance(summary['strengths'], list)
        assert isinstance(summary['key_opportunities'], list)
        assert isinstance(summary['potential_impact'], str)
    
    def test_email_template_structure(self, prospect_site_data):
        """Test email template structure and content."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        opportunities = analyzer._audit_missed_opportunities(prospect_site_data)
        proposal = analyzer._generate_mini_proposal(prospect_site_data, opportunities)
        
        email_template = proposal['email_template']
        
        # Should contain key email components
        assert 'Subject:' in email_template
        assert 'Hi there,' in email_template or 'Hi' in email_template
        assert 'prospect.com' in email_template
        assert 'Best regards' in email_template or 'Best' in email_template
        
        # Should mention opportunities
        assert '1.' in email_template  # Numbered opportunities
        assert 'opportunity' in email_template.lower() or 'opportunities' in email_template.lower()
        
        # Should include call to action
        assert 'call' in email_template.lower() or 'discussion' in email_template.lower() or 'interested' in email_template.lower()
    
    def test_prospect_recommendations_structure(self, prospect_site_data):
        """Test that prospect recommendations have proper structure."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=prospect_site_data):
            result = analyzer.analyze_site("https://prospect.com", AnalysisMode.PROSPECT)
        
        # Check recommendations structure
        for rec in result.recommendations:
            assert 'category' in rec
            assert 'priority' in rec
            assert 'title' in rec
            assert 'description' in rec
            
            # Prospect-specific fields
            assert rec['category'] == 'Growth Opportunity'
            assert rec['priority'] == 'high'  # Prospects should see high-priority items
            assert 'business_impact' in rec
            assert 'solution' in rec
            assert 'estimated_effort' in rec
            
            # Check valid effort levels
            assert rec['estimated_effort'] in ['low', 'medium', 'high']
    
    def test_prospect_raw_data_completeness(self, prospect_site_data):
        """Test that raw_data contains all expected components."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=prospect_site_data):
            result = analyzer.analyze_site("https://prospect.com", AnalysisMode.PROSPECT)
        
        # Check raw_data structure for prospect mode
        assert result.raw_data is not None
        assert 'missed_opportunities_audit' in result.raw_data
        assert 'mini_proposal' in result.raw_data
        assert 'email_template' in result.raw_data
        
        # Verify each component has expected structure
        audit = result.raw_data['missed_opportunities_audit']
        assert isinstance(audit, list)
        
        proposal = result.raw_data['mini_proposal']
        assert 'audit_score' in proposal
        assert 'email_template' in proposal
        
        email_template = result.raw_data['email_template']
        assert isinstance(email_template, str)
        assert len(email_template) > 0
    
    def test_prospect_json_serializable(self, prospect_site_data):
        """Test that prospect results are JSON serializable."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=prospect_site_data):
            result = analyzer.analyze_site("https://prospect.com", AnalysisMode.PROSPECT)
        
        # Convert to dict and serialize
        result_dict = {
            'mode': result.mode,
            'domain': result.domain,
            'timestamp': result.timestamp,
            'summary': result.summary,
            'recommendations': result.recommendations,
            'metadata': result.metadata,
            'raw_data': result.raw_data
        }
        
        # Should not raise an exception
        json_str = json.dumps(result_dict, indent=2)
        assert len(json_str) > 0
        
        # Should be deserializable
        parsed = json.loads(json_str)
        assert parsed['mode'] == 'prospect'
        assert parsed['domain'] == 'prospect.com'
    
    def test_audit_score_calculation(self, prospect_site_data):
        """Test audit score calculation logic."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        opportunities = analyzer._audit_missed_opportunities(prospect_site_data)
        proposal = analyzer._generate_mini_proposal(prospect_site_data, opportunities)
        
        # Score should be in correct format
        audit_score = proposal['audit_score']
        score_parts = audit_score.split('/')
        assert len(score_parts) == 2
        assert score_parts[1] == '100'
        
        # Score should be numeric
        score_value = int(score_parts[0])
        assert 0 <= score_value <= 100
        
        # With issues in prospect_site_data, score should be less than 100
        assert score_value < 100
    
    def test_high_impact_opportunities_identification(self, prospect_site_data):
        """Test identification of high-impact opportunities."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        opportunities = analyzer._audit_missed_opportunities(prospect_site_data)
        
        # Should have at least some high-impact opportunities
        high_impact_count = len([opp for opp in opportunities if opp['impact_level'] == 'high'])
        assert high_impact_count > 0
        
        # Business impact should be descriptive
        for opp in opportunities:
            if opp['impact_level'] == 'high':
                assert len(opp['business_impact']) > 10  # Should be descriptive
                assert len(opp['solution']) > 10  # Should provide clear solution
    
    def test_prospect_metadata_completeness(self, prospect_site_data):
        """Test prospect metadata completeness."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=prospect_site_data):
            result = analyzer.analyze_site("https://prospect.com", AnalysisMode.PROSPECT)
        
        # Check prospect-specific metadata
        metadata = result.metadata
        assert metadata['analysis_type'] == 'prospect_audit'
        assert metadata['proposal_ready'] is True
        assert metadata['email_friendly_format'] is True
        assert metadata['client_presentation_ready'] is True


class TestProspectEdgeCases:
    """Test edge cases for prospect analysis."""
    
    def test_perfect_prospect_site(self):
        """Test prospect site with minimal issues."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        # Create near-perfect site data
        perfect_pages = []
        for i in range(25):  # Sufficient content volume
            page = PageData(
                url=f"https://perfect-prospect.com/page-{i}",
                title=f"Perfect Page {i} - Optimized Title Length",
                meta_description=f"Perfect meta description for page {i} that is exactly the right length and contains relevant keywords for better search optimization.",
                h1_tags=[f"Perfect H1 Tag {i}"],
                h2_tags=[f"Section 1", f"Section 2"],
                word_count=1000 + i * 50,  # Good content length
                internal_links=[f"https://perfect-prospect.com/page-{j}" for j in range(i) if j != i],
                external_links=["https://authority.com"]
            )
            perfect_pages.append(page)
        
        perfect_site_data = SiteData(
            domain="perfect-prospect.com",
            base_url="https://perfect-prospect.com",
            total_pages=25,
            pages=perfect_pages,
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={}
        )
        
        opportunities = analyzer._audit_missed_opportunities(perfect_site_data)
        
        # Should still find some opportunities (performance optimization is always suggested)
        assert len(opportunities) > 0
        
        # But fewer high-impact opportunities
        high_impact_count = len([opp for opp in opportunities if opp['impact_level'] == 'high'])
        assert high_impact_count <= 2  # Should be minimal for good sites
        
        # Audit score should be higher
        proposal = analyzer._generate_mini_proposal(perfect_site_data, opportunities)
        score_value = int(proposal['audit_score'].split('/')[0])
        assert score_value >= 70  # Should be relatively high
    
    def test_empty_prospect_site(self):
        """Test handling of empty prospect site."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        empty_site_data = SiteData(
            domain="empty-prospect.com",
            base_url="https://empty-prospect.com",
            total_pages=0,
            pages=[],
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={}
        )
        
        with patch.object(analyzer, '_crawl_site', return_value=empty_site_data):
            result = analyzer.analyze_site("https://empty-prospect.com", AnalysisMode.PROSPECT)
        
        # Should handle empty sites gracefully
        assert result.mode == "prospect"
        assert result.summary['total_pages_analyzed'] == 0
        assert isinstance(result.recommendations, list)
        assert result.summary['proposal_generated'] is True
        
        # Should still generate email template
        assert result.raw_data['email_template']
        assert len(result.raw_data['email_template']) > 0
    
    def test_single_page_prospect_site(self):
        """Test prospect analysis for single-page sites."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        single_page_data = SiteData(
            domain="single-prospect.com",
            base_url="https://single-prospect.com",
            total_pages=1,
            pages=[
                PageData(
                    url="https://single-prospect.com/",
                    title="Single Page Business Site",
                    meta_description="Single page business",
                    h1_tags=["Welcome"],
                    h2_tags=[],
                    word_count=200,
                    internal_links=[],
                    external_links=[]
                )
            ],
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={}
        )
        
        with patch.object(analyzer, '_crawl_site', return_value=single_page_data):
            result = analyzer.analyze_site("https://single-prospect.com", AnalysisMode.PROSPECT)
        
        # Should identify limited content volume as major opportunity
        assert result.summary['total_pages_analyzed'] == 1
        
        opportunity_titles = [rec['title'] for rec in result.recommendations]
        assert any('Content' in title for title in opportunity_titles)
        
        # Should have high-impact recommendations for single-page sites
        high_impact_count = result.summary['high_impact_opportunities']
        assert high_impact_count > 0
    
    def test_prospect_email_domain_extraction(self):
        """Test that email template correctly uses domain names."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        test_cases = [
            "https://my-business.com",
            "https://www.company-name.co.uk",
            "https://startup.io/",
        ]
        
        for url in test_cases:
            # Mock minimal site data
            minimal_pages = [
                PageData(
                    url=url,
                    title="Test Page",
                    meta_description="",
                    h1_tags=["Test"],
                    h2_tags=[],
                    word_count=100,
                    internal_links=[],
                    external_links=[]
                )
            ]
            
            from urllib.parse import urlparse
            domain = urlparse(url).netloc
            if domain.startswith('www.'):
                domain = domain[4:]
            
            site_data = SiteData(
                domain=domain,
                base_url=url,
                total_pages=1,
                pages=minimal_pages,
                crawl_timestamp=datetime.now().isoformat(),
                analysis_metadata={}
            )
            
            with patch.object(analyzer, '_crawl_site', return_value=site_data):
                result = analyzer.analyze_site(url, AnalysisMode.PROSPECT)
            
            # Email template should contain the domain
            email_template = result.raw_data['email_template']
            assert domain in email_template


