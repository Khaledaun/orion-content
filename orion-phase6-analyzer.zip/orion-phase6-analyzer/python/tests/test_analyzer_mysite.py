
"""
Tests for my-site analysis mode - Phase 6 Orion Content Analyzer.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
import json
from datetime import datetime

from orion.analyze.analyzer import SiteAnalyzer, AnalysisMode, SiteData, PageData, AnalysisResult


class TestMySiteAnalyzer:
    """Test suite for my-site analysis mode."""
    
    @pytest.fixture
    def sample_site_data(self):
        """Create sample site data for testing."""
        pages = [
            PageData(
                url="https://mysite.com/",
                title="Welcome to My Site - Home Page",
                meta_description="The ultimate guide to everything",
                h1_tags=["Welcome to My Site"],
                h2_tags=["Our Services", "Contact Us"],
                word_count=500,
                internal_links=["https://mysite.com/about", "https://mysite.com/services"],
                external_links=["https://google.com"]
            ),
            PageData(
                url="https://mysite.com/about",
                title="About Us - My Site",
                meta_description="Learn about our company",
                h1_tags=["About Our Company"],
                h2_tags=["Our History", "Our Team"],
                word_count=300,
                internal_links=["https://mysite.com/", "https://mysite.com/contact"],
                external_links=[]
            ),
            PageData(
                url="https://mysite.com/services",
                title="Our Services - My Site",
                meta_description="",  # Missing meta description
                h1_tags=["Our Services"],
                h2_tags=["Web Development", "SEO Services"],
                word_count=800,
                internal_links=["https://mysite.com/"],
                external_links=["https://example.com"]
            ),
            PageData(
                url="https://mysite.com/blog/hidden-page",
                title="Hidden Blog Post - My Site - The Ultimate Guide to Hidden Content That Nobody Links To",  # Long title
                meta_description="This page has very few internal links",
                h1_tags=["Hidden Content"],
                h2_tags=["Why This Matters"],
                word_count=1200,
                internal_links=[],
                external_links=[]
            )
        ]
        
        return SiteData(
            domain="mysite.com",
            base_url="https://mysite.com",
            total_pages=4,
            pages=pages,
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={'max_pages_limit': 50, 'actual_pages_crawled': 4}
        )
    
    def test_my_site_analysis_basic(self, sample_site_data):
        """Test basic my-site analysis functionality."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=sample_site_data):
            result = analyzer.analyze_site("https://mysite.com", AnalysisMode.MY_SITE)
        
        # Check basic result structure
        assert result.mode == "my-site"
        assert result.domain == "mysite.com"
        assert isinstance(result.summary, dict)
        assert isinstance(result.recommendations, list)
        assert isinstance(result.metadata, dict)
        
        # Check summary content
        assert result.summary['total_pages_analyzed'] == 4
        assert 'seo_score' in result.summary
        assert 'technical_issues_found' in result.summary
        assert 'orphan_pages_identified' in result.summary
        assert 'site_category' in result.summary
    
    def test_technical_seo_audit(self, sample_site_data):
        """Test technical SEO audit functionality."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        seo_audit = analyzer._perform_technical_seo_audit(sample_site_data)
        
        # Check audit structure
        assert 'score' in seo_audit
        assert 'issues' in seo_audit
        assert 'top_h1_keywords' in seo_audit
        assert 'statistics' in seo_audit
        
        # Check that issues are found
        assert len(seo_audit['issues']) > 0
        
        # Should detect missing meta description
        issue_titles = [issue['title'] for issue in seo_audit['issues']]
        assert any('Meta Description' in title for title in issue_titles)
        
        # Should detect title length issues
        assert any('Title Length' in title for title in issue_titles)
        
        # Check statistics
        stats = seo_audit['statistics']
        assert stats['total_pages'] == 4
        assert stats['pages_with_titles'] == 4
        assert stats['pages_with_meta_descriptions'] == 3  # One missing
    
    def test_site_blueprint_generation(self, sample_site_data):
        """Test site blueprint generation."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        blueprint = analyzer._generate_site_blueprint(sample_site_data)
        
        # Check blueprint structure
        assert 'category' in blueprint
        assert 'content_archetypes' in blueprint
        assert 'persona' in blueprint
        assert 'target_audience' in blueprint
        assert 'tone_of_voice' in blueprint
        assert 'strategy_recommendations' in blueprint
        
        # Check that it identified some content archetypes
        assert isinstance(blueprint['content_archetypes'], list)
        assert isinstance(blueprint['strategy_recommendations'], list)
        assert len(blueprint['strategy_recommendations']) > 0
    
    def test_internal_linking_analysis(self, sample_site_data):
        """Test internal linking analysis."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        linking_analysis = analyzer._analyze_internal_linking(sample_site_data)
        
        # Check structure
        assert 'orphan_pages' in linking_analysis
        assert 'total_internal_links' in linking_analysis
        assert 'pages_analyzed' in linking_analysis
        assert 'linking_recommendations' in linking_analysis
        
        # Should identify the hidden page as orphan
        orphan_pages = linking_analysis['orphan_pages']
        assert len(orphan_pages) > 0
        
        # Check that orphan page data is complete
        for orphan in orphan_pages:
            assert 'url' in orphan
            assert 'title' in orphan
            assert 'internal_link_count' in orphan
            assert 'word_count' in orphan
    
    def test_my_site_recommendations_structure(self, sample_site_data):
        """Test that recommendations have proper structure."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=sample_site_data):
            result = analyzer.analyze_site("https://mysite.com", AnalysisMode.MY_SITE)
        
        # Check recommendations structure
        for rec in result.recommendations:
            assert 'category' in rec
            assert 'priority' in rec
            assert 'title' in rec
            assert 'description' in rec
            
            # My-site specific fields
            if 'action_items' in rec:
                assert isinstance(rec['action_items'], list)
    
    def test_raw_data_completeness(self, sample_site_data):
        """Test that raw_data contains all expected components."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=sample_site_data):
            result = analyzer.analyze_site("https://mysite.com", AnalysisMode.MY_SITE)
        
        # Check raw_data structure for my-site mode
        assert result.raw_data is not None
        assert 'seo_audit' in result.raw_data
        assert 'site_blueprint' in result.raw_data
        assert 'linking_opportunities' in result.raw_data
        
        # Verify each component has expected structure
        seo_audit = result.raw_data['seo_audit']
        assert 'score' in seo_audit
        assert 'issues' in seo_audit
        
        blueprint = result.raw_data['site_blueprint']
        assert 'category' in blueprint
        assert 'content_archetypes' in blueprint
        
        linking = result.raw_data['linking_opportunities']
        assert 'orphan_pages' in linking
    
    def test_my_site_json_serializable(self, sample_site_data):
        """Test that my-site results are JSON serializable."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=sample_site_data):
            result = analyzer.analyze_site("https://mysite.com", AnalysisMode.MY_SITE)
        
        # Convert to dict and serialize
        result_dict = {
            'mode': result.mode,
            'domain': result.domain,
            'timestamp': result.timestamp,
            'summary': result.summary,
            'recommendations': result.recommendations,
            'metadata': result.metadata,
            'raw_data': result.raw_data
        }
        
        # Should not raise an exception
        json_str = json.dumps(result_dict, indent=2)
        assert len(json_str) > 0
        
        # Should be deserializable
        parsed = json.loads(json_str)
        assert parsed['mode'] == 'my-site'
        assert parsed['domain'] == 'mysite.com'
    
    @patch('orion.analyze.analyzer.requests.Session.get')
    def test_crawl_failure_handling(self, mock_get):
        """Test handling of crawl failures."""
        # Mock request failure
        mock_get.side_effect = Exception("Connection error")
        
        analyzer = SiteAnalyzer(use_llm=False, max_pages=5)
        result = analyzer.analyze_site("https://invalid-site.com", AnalysisMode.MY_SITE)
        
        # Should return error result
        assert result.summary['error'] is True
        assert 'error_message' in result.summary
        assert result.metadata['analysis_type'] == 'failed'
    
    def test_seo_score_calculation(self, sample_site_data):
        """Test SEO score calculation logic."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        seo_audit = analyzer._perform_technical_seo_audit(sample_site_data)
        
        # Score should be between 0 and 100
        assert 0 <= seo_audit['score'] <= 100
        
        # With issues present, score should be less than 100
        assert seo_audit['score'] < 100
        
        # Score should decrease based on number of issues
        issue_count = len(seo_audit['issues'])
        assert issue_count > 0  # We know there are issues in sample data


class TestMySiteEdgeCases:
    """Test edge cases for my-site analysis."""
    
    def test_empty_site_data(self):
        """Test handling of empty site data."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        empty_site_data = SiteData(
            domain="empty.com",
            base_url="https://empty.com",
            total_pages=0,
            pages=[],
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={}
        )
        
        with patch.object(analyzer, '_crawl_site', return_value=empty_site_data):
            result = analyzer.analyze_site("https://empty.com", AnalysisMode.MY_SITE)
        
        # Should handle gracefully
        assert result.mode == "my-site"
        assert result.summary['total_pages_analyzed'] == 0
        assert isinstance(result.recommendations, list)
    
    def test_single_page_site(self):
        """Test handling of single page sites."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        single_page_data = SiteData(
            domain="single.com",
            base_url="https://single.com",
            total_pages=1,
            pages=[
                PageData(
                    url="https://single.com/",
                    title="Single Page Site",
                    meta_description="Only one page",
                    h1_tags=["Welcome"],
                    h2_tags=[],
                    word_count=200,
                    internal_links=[],
                    external_links=[]
                )
            ],
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={}
        )
        
        with patch.object(analyzer, '_crawl_site', return_value=single_page_data):
            result = analyzer.analyze_site("https://single.com", AnalysisMode.MY_SITE)
        
        # Should handle single page sites
        assert result.summary['total_pages_analyzed'] == 1
        assert result.summary['orphan_pages_identified'] == 0  # No orphans for single page
    
    def test_perfect_seo_site(self):
        """Test site with perfect SEO (no issues)."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        perfect_pages = [
            PageData(
                url="https://perfect.com/",
                title="Perfect SEO Site - 50 Characters Title",
                meta_description="Perfect meta description that is exactly the right length for SEO and contains relevant keywords for better search engine optimization.",
                h1_tags=["Perfect SEO Guide"],
                h2_tags=["SEO Best Practices"],
                word_count=1000,
                internal_links=["https://perfect.com/about"],
                external_links=[]
            ),
            PageData(
                url="https://perfect.com/about",
                title="About Perfect SEO - Unique Title 45 Chars",
                meta_description="Learn about our perfect SEO practices and methodology that helps websites rank higher in search engine results pages.",
                h1_tags=["About Perfect SEO"],
                h2_tags=["Our Methodology"],
                word_count=800,
                internal_links=["https://perfect.com/"],
                external_links=[]
            )
        ]
        
        perfect_site_data = SiteData(
            domain="perfect.com",
            base_url="https://perfect.com",
            total_pages=2,
            pages=perfect_pages,
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={}
        )
        
        seo_audit = analyzer._perform_technical_seo_audit(perfect_site_data)
        
        # Should have high SEO score with minimal issues
        assert seo_audit['score'] >= 85
        assert len(seo_audit['issues']) <= 1  # Minimal issues if any


