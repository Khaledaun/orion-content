
"""
Tests for competitor analysis mode - Phase 6 Orion Content Analyzer.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
import json
from datetime import datetime

from orion.analyze.analyzer import SiteAnalyzer, AnalysisMode, SiteData, PageData, AnalysisResult


class TestCompetitorAnalyzer:
    """Test suite for competitor analysis mode."""
    
    @pytest.fixture
    def competitor_site_data(self):
        """Create sample competitor site data for testing."""
        pages = [
            PageData(
                url="https://competitor.com/",
                title="Best Marketing Tips - Competitor Blog",
                meta_description="Top marketing strategies for business growth",
                h1_tags=["Marketing Tips"],
                h2_tags=["Digital Marketing", "Content Strategy"],
                word_count=600,
                internal_links=["https://competitor.com/blog", "https://competitor.com/services"],
                external_links=["https://hubspot.com"]
            ),
            PageData(
                url="https://competitor.com/blog/seo-guide",
                title="Ultimate SEO Guide - How to Rank Higher",
                meta_description="Complete SEO guide for better rankings",
                h1_tags=["SEO Guide"],
                h2_tags=["Keyword Research", "Technical SEO"],
                word_count=2000,
                internal_links=["https://competitor.com/", "https://competitor.com/blog"],
                external_links=["https://moz.com", "https://semrush.com"]
            ),
            PageData(
                url="https://competitor.com/reviews/best-tools",
                title="Best Marketing Tools Review 2024",
                meta_description="Top marketing tools comparison and reviews",
                h1_tags=["Best Marketing Tools"],
                h2_tags=["Email Marketing Tools", "Analytics Tools"],
                word_count=1500,
                internal_links=["https://competitor.com/"],
                external_links=["https://mailchimp.com", "https://google.com/analytics"]
            ),
            PageData(
                url="https://competitor.com/how-to/social-media",
                title="How to Dominate Social Media Marketing",
                meta_description="Social media marketing strategies that work",
                h1_tags=["Social Media Marketing"],
                h2_tags=["Facebook Marketing", "Instagram Tips"],
                word_count=1200,
                internal_links=["https://competitor.com/blog"],
                external_links=["https://facebook.com", "https://instagram.com"]
            ),
            PageData(
                url="https://competitor.com/business/growth-hacks",
                title="Top 10 Business Growth Hacks for Startups",
                meta_description="Proven business growth strategies",
                h1_tags=["Business Growth Hacks"],
                h2_tags=["Customer Acquisition", "Revenue Growth"],
                word_count=1000,
                internal_links=["https://competitor.com/"],
                external_links=["https://techcrunch.com"]
            )
        ]
        
        return SiteData(
            domain="competitor.com",
            base_url="https://competitor.com",
            total_pages=5,
            pages=pages,
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={'max_pages_limit': 50, 'actual_pages_crawled': 5}
        )
    
    def test_competitor_analysis_basic(self, competitor_site_data):
        """Test basic competitor analysis functionality."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=competitor_site_data):
            result = analyzer.analyze_site("https://competitor.com", AnalysisMode.COMPETITOR)
        
        # Check basic result structure
        assert result.mode == "competitor"
        assert result.domain == "competitor.com"
        assert isinstance(result.summary, dict)
        assert isinstance(result.recommendations, list)
        assert isinstance(result.metadata, dict)
        
        # Check competitor-specific summary content
        assert result.summary['total_pages_analyzed'] == 5
        assert 'primary_content_formats' in result.summary
        assert 'topical_clusters_identified' in result.summary
        assert 'target_keywords_identified' in result.summary
        assert 'strategic_opportunities' in result.summary
        assert 'competitor_tone' in result.summary
        assert 'content_gaps_found' in result.summary
    
    def test_content_strategy_analysis(self, competitor_site_data):
        """Test content strategy analysis functionality."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        content_strategy = analyzer._analyze_content_strategy(competitor_site_data)
        
        # Check structure
        assert 'primary_formats' in content_strategy
        assert 'topical_clusters' in content_strategy
        assert 'tone_of_voice' in content_strategy
        assert 'content_volume' in content_strategy
        assert 'average_content_length' in content_strategy
        
        # Should identify content formats from titles
        formats = content_strategy['primary_formats']
        assert 'How-to Guides' in formats  # "How to Dominate..."
        assert 'Reviews' in formats  # "Best Marketing Tools Review..."
        
        # Should identify topical clusters
        clusters = content_strategy['topical_clusters']
        assert 'Marketing' in clusters  # Multiple marketing-related pages
        assert 'Business' in clusters  # Business growth content
        
        # Content volume should match
        assert content_strategy['content_volume'] == 5
        
        # Average content length should be calculated
        assert content_strategy['average_content_length'] > 0
    
    def test_keyword_strategy_analysis(self, competitor_site_data):
        """Test keyword strategy analysis functionality."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        keyword_strategy = analyzer._analyze_keyword_strategy(competitor_site_data)
        
        # Check structure
        assert 'target_keywords' in keyword_strategy
        assert 'keyword_density_patterns' in keyword_strategy
        assert 'long_tail_usage' in keyword_strategy
        
        # Should identify common keywords
        target_keywords = keyword_strategy['target_keywords']
        assert len(target_keywords) > 0
        
        # Should find marketing-related keywords
        keyword_list = [kw[0] for kw in target_keywords]
        assert any('marketing' in keyword_list)
        
        # Should detect long-tail usage
        assert keyword_strategy['long_tail_usage'] in ['present', 'limited']
    
    def test_strategic_opportunities_identification(self, competitor_site_data):
        """Test strategic opportunities identification."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        content_strategy = analyzer._analyze_content_strategy(competitor_site_data)
        keyword_strategy = analyzer._analyze_keyword_strategy(competitor_site_data)
        
        opportunities = analyzer._identify_strategic_opportunities(
            competitor_site_data, content_strategy, keyword_strategy
        )
        
        # Check structure
        assert isinstance(opportunities, list)
        
        for opp in opportunities:
            assert 'title' in opp
            assert 'description' in opp
            assert 'type' in opp
            assert 'priority' in opp
            assert 'advantage' in opp
            assert 'action_items' in opp
            
            # Check that priority is valid
            assert opp['priority'] in ['low', 'medium', 'high']
            
            # Check that action_items is a list
            assert isinstance(opp['action_items'], list)
            assert len(opp['action_items']) > 0
    
    def test_competitor_recommendations_structure(self, competitor_site_data):
        """Test that competitor recommendations have proper structure."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=competitor_site_data):
            result = analyzer.analyze_site("https://competitor.com", AnalysisMode.COMPETITOR)
        
        # Check recommendations structure
        for rec in result.recommendations:
            assert 'category' in rec
            assert 'priority' in rec
            assert 'title' in rec
            assert 'description' in rec
            
            # Competitor-specific fields
            assert rec['category'] == 'Competitive Opportunity'
            assert 'action_items' in rec
            assert 'competitive_advantage' in rec
            
            # Check valid priority levels
            assert rec['priority'] in ['low', 'medium', 'high']
    
    def test_competitor_raw_data_completeness(self, competitor_site_data):
        """Test that raw_data contains all expected components."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=competitor_site_data):
            result = analyzer.analyze_site("https://competitor.com", AnalysisMode.COMPETITOR)
        
        # Check raw_data structure for competitor mode
        assert result.raw_data is not None
        assert 'content_strategy' in result.raw_data
        assert 'keyword_strategy' in result.raw_data
        assert 'strategic_opportunities' in result.raw_data
        
        # Verify each component has expected structure
        content_strategy = result.raw_data['content_strategy']
        assert 'primary_formats' in content_strategy
        assert 'topical_clusters' in content_strategy
        
        keyword_strategy = result.raw_data['keyword_strategy']
        assert 'target_keywords' in keyword_strategy
        
        opportunities = result.raw_data['strategic_opportunities']
        assert isinstance(opportunities, list)
    
    def test_competitor_json_serializable(self, competitor_site_data):
        """Test that competitor results are JSON serializable."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        with patch.object(analyzer, '_crawl_site', return_value=competitor_site_data):
            result = analyzer.analyze_site("https://competitor.com", AnalysisMode.COMPETITOR)
        
        # Convert to dict and serialize
        result_dict = {
            'mode': result.mode,
            'domain': result.domain,
            'timestamp': result.timestamp,
            'summary': result.summary,
            'recommendations': result.recommendations,
            'metadata': result.metadata,
            'raw_data': result.raw_data
        }
        
        # Should not raise an exception
        json_str = json.dumps(result_dict, indent=2)
        assert len(json_str) > 0
        
        # Should be deserializable
        parsed = json.loads(json_str)
        assert parsed['mode'] == 'competitor'
        assert parsed['domain'] == 'competitor.com'
    
    def test_limited_topical_authority_opportunity(self):
        """Test identification of limited topical authority opportunity."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        # Create site data with limited topical diversity
        limited_pages = [
            PageData(
                url="https://narrow.com/seo1",
                title="SEO Tips",
                meta_description="",
                h1_tags=["SEO"],
                h2_tags=[],
                word_count=500,
                internal_links=[],
                external_links=[]
            ),
            PageData(
                url="https://narrow.com/seo2",
                title="More SEO Tips",
                meta_description="",
                h1_tags=["SEO"],
                h2_tags=[],
                word_count=500,
                internal_links=[],
                external_links=[]
            )
        ]
        
        limited_site_data = SiteData(
            domain="narrow.com",
            base_url="https://narrow.com",
            total_pages=2,
            pages=limited_pages,
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={}
        )
        
        content_strategy = analyzer._analyze_content_strategy(limited_site_data)
        keyword_strategy = analyzer._analyze_keyword_strategy(limited_site_data)
        
        opportunities = analyzer._identify_strategic_opportunities(
            limited_site_data, content_strategy, keyword_strategy
        )
        
        # Should identify limited topical authority
        opportunity_titles = [opp['title'] for opp in opportunities]
        assert any('Limited Topical Authority' in title for title in opportunity_titles)
    
    def test_content_depth_opportunity(self):
        """Test identification of content depth opportunity."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        # Create site data with shallow content
        shallow_pages = [
            PageData(
                url="https://shallow.com/page1",
                title="Short Article",
                meta_description="",
                h1_tags=["Article"],
                h2_tags=[],
                word_count=200,  # Very short content
                internal_links=[],
                external_links=[]
            ),
            PageData(
                url="https://shallow.com/page2",
                title="Another Short Article",
                meta_description="",
                h1_tags=["Article"],
                h2_tags=[],
                word_count=300,  # Also short
                internal_links=[],
                external_links=[]
            )
        ]
        
        shallow_site_data = SiteData(
            domain="shallow.com",
            base_url="https://shallow.com",
            total_pages=2,
            pages=shallow_pages,
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={}
        )
        
        content_strategy = analyzer._analyze_content_strategy(shallow_site_data)
        keyword_strategy = analyzer._analyze_keyword_strategy(shallow_site_data)
        
        opportunities = analyzer._identify_strategic_opportunities(
            shallow_site_data, content_strategy, keyword_strategy
        )
        
        # Should identify content depth opportunity
        opportunity_titles = [opp['title'] for opp in opportunities]
        assert any('Content Depth' in title for title in opportunity_titles)


class TestCompetitorEdgeCases:
    """Test edge cases for competitor analysis."""
    
    def test_competitor_no_clear_strategy(self):
        """Test competitor with no clear content strategy."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        random_pages = [
            PageData(
                url="https://random.com/page1",
                title="Random Page One",
                meta_description="",
                h1_tags=["Random Content"],
                h2_tags=[],
                word_count=400,
                internal_links=[],
                external_links=[]
            ),
            PageData(
                url="https://random.com/page2",
                title="Unrelated Page Two",
                meta_description="",
                h1_tags=["Different Topic"],
                h2_tags=[],
                word_count=300,
                internal_links=[],
                external_links=[]
            )
        ]
        
        random_site_data = SiteData(
            domain="random.com",
            base_url="https://random.com",
            total_pages=2,
            pages=random_pages,
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={}
        )
        
        with patch.object(analyzer, '_crawl_site', return_value=random_site_data):
            result = analyzer.analyze_site("https://random.com", AnalysisMode.COMPETITOR)
        
        # Should handle sites with unclear strategy
        assert result.mode == "competitor"
        assert result.summary['total_pages_analyzed'] == 2
        assert isinstance(result.summary['primary_content_formats'], list)
        assert isinstance(result.recommendations, list)
    
    def test_competitor_high_quality_site(self):
        """Test competitor with high-quality, comprehensive strategy."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        # Create comprehensive competitor data
        comprehensive_pages = []
        content_formats = ['guide', 'review', 'how-to', 'list', 'case study', 'tutorial']
        topics = ['marketing', 'business', 'technology', 'health', 'finance']
        
        for i, (format_type, topic) in enumerate(zip(content_formats, topics)):
            page = PageData(
                url=f"https://comprehensive.com/{format_type}-{i}",
                title=f"Ultimate {topic.title()} {format_type.title()}",
                meta_description=f"Comprehensive {topic} {format_type}",
                h1_tags=[f"{topic.title()} {format_type.title()}"],
                h2_tags=[f"{topic.title()} Section 1", f"{topic.title()} Section 2"],
                word_count=2000 + i * 200,  # Increasing word count
                internal_links=[f"https://comprehensive.com/{format_type}-{j}" for j in range(i)],
                external_links=[f"https://authority-site-{j}.com" for j in range(2)]
            )
            comprehensive_pages.append(page)
        
        comprehensive_site_data = SiteData(
            domain="comprehensive.com",
            base_url="https://comprehensive.com",
            total_pages=len(comprehensive_pages),
            pages=comprehensive_pages,
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={}
        )
        
        with patch.object(analyzer, '_crawl_site', return_value=comprehensive_site_data):
            result = analyzer.analyze_site("https://comprehensive.com", AnalysisMode.COMPETITOR)
        
        # Should identify fewer opportunities for high-quality sites
        assert result.mode == "competitor"
        assert result.summary['total_pages_analyzed'] == len(comprehensive_pages)
        assert len(result.summary['primary_content_formats']) >= 3
        assert len(result.summary['topical_clusters_identified']) >= 3
    
    def test_empty_competitor_data(self):
        """Test handling of empty competitor data."""
        analyzer = SiteAnalyzer(use_llm=False)
        
        empty_site_data = SiteData(
            domain="empty.com",
            base_url="https://empty.com",
            total_pages=0,
            pages=[],
            crawl_timestamp=datetime.now().isoformat(),
            analysis_metadata={}
        )
        
        with patch.object(analyzer, '_crawl_site', return_value=empty_site_data):
            result = analyzer.analyze_site("https://empty.com", AnalysisMode.COMPETITOR)
        
        # Should handle empty sites gracefully
        assert result.mode == "competitor"
        assert result.summary['total_pages_analyzed'] == 0
        assert isinstance(result.recommendations, list)
        assert result.summary['topical_clusters_identified'] == 0


